-- ============================================================
-- BASE DE DATOS: BibliotecaDB
-- Script de creación y datos de prueba
-- ============================================================

IF DB_ID('BibliotecaDB') IS NULL
BEGIN
    CREATE DATABASE BibliotecaDB;
END
GO

USE BibliotecaDB;
GO

-- ============================================================
-- ELIMINAR TABLAS SI EXISTEN (para poder ejecutar el script
-- desde cero durante una prueba)
-- ============================================================

IF OBJECT_ID('dbo.DetallePrestamos', 'U') IS NOT NULL
    DROP TABLE dbo.DetallePrestamos;
GO

IF OBJECT_ID('dbo.Prestamos', 'U') IS NOT NULL
    DROP TABLE dbo.Prestamos;
GO

IF OBJECT_ID('dbo.Libros', 'U') IS NOT NULL
    DROP TABLE dbo.Libros;
GO

IF OBJECT_ID('dbo.Usuarios', 'U') IS NOT NULL
    DROP TABLE dbo.Usuarios;
GO

IF OBJECT_ID('dbo.Autores', 'U') IS NOT NULL
    DROP TABLE dbo.Autores;
GO

IF OBJECT_ID('dbo.Categorias', 'U') IS NOT NULL
    DROP TABLE dbo.Categorias;
GO

-- ============================================================
-- TABLA AUTORES
-- ============================================================

CREATE TABLE dbo.Autores
(
    IdAutor INT IDENTITY(1,1) NOT NULL,
    Codigo VARCHAR(20) NOT NULL,
    Nombre VARCHAR(50) NOT NULL,
    Apellidos VARCHAR(80) NOT NULL,
    Nacionalidad VARCHAR(50) NOT NULL,
    FechaNacimiento DATE NOT NULL,

    CONSTRAINT PK_Autores
        PRIMARY KEY (IdAutor)
);
GO

-- ============================================================
-- TABLA CATEGORIAS
-- ============================================================

CREATE TABLE dbo.Categorias
(
    IdCategoria INT IDENTITY(1,1) NOT NULL,
    Nombre VARCHAR(50) NOT NULL,

    CONSTRAINT PK_Categorias
        PRIMARY KEY (IdCategoria)
);
GO

-- ============================================================
-- TABLA LIBROS
-- ============================================================

CREATE TABLE dbo.Libros
(
    IdLibro INT IDENTITY(1,1) NOT NULL,
    Codigo VARCHAR(20) NOT NULL,
    ISBN VARCHAR(20) NOT NULL,
    Titulo VARCHAR(150) NOT NULL,
    IdAutor INT NOT NULL,
    IdCategoria INT NOT NULL,
    Cantidad INT NOT NULL,
    Disponible INT NOT NULL,

    CONSTRAINT PK_Libros
        PRIMARY KEY (IdLibro),

    CONSTRAINT FK_Libros_Autores
        FOREIGN KEY (IdAutor)
        REFERENCES dbo.Autores(IdAutor),

    CONSTRAINT FK_Libros_Categorias
        FOREIGN KEY (IdCategoria)
        REFERENCES dbo.Categorias(IdCategoria)
);
GO

-- ============================================================
-- TABLA USUARIOS
-- ============================================================

CREATE TABLE dbo.Usuarios
(
    IdUsuario INT IDENTITY(1,1) NOT NULL,
    Documento VARCHAR(20) NOT NULL,
    Nombre VARCHAR(50) NOT NULL,
    Apellidos VARCHAR(80) NOT NULL,
    Telefono VARCHAR(20) NOT NULL,
    Correo VARCHAR(100) NOT NULL,
    ProgramaAcademico VARCHAR(100) NOT NULL,

    CONSTRAINT PK_Usuarios
        PRIMARY KEY (IdUsuario)
);
GO

-- ============================================================
-- TABLA PRESTAMOS
-- ============================================================

CREATE TABLE dbo.Prestamos
(
    IdPrestamo INT IDENTITY(1,1) NOT NULL,
    IdUsuario INT NOT NULL,
    FechaPrestamo DATETIME2 NOT NULL,
    FechaDevolucionEsperada DATE NOT NULL,
    Estado VARCHAR(20) NOT NULL,

    CONSTRAINT PK_Prestamos
        PRIMARY KEY (IdPrestamo),

    CONSTRAINT FK_Prestamos_Usuarios
        FOREIGN KEY (IdUsuario)
        REFERENCES dbo.Usuarios(IdUsuario)
);
GO

-- ============================================================
-- TABLA DETALLE DE PRESTAMOS
-- ============================================================

CREATE TABLE dbo.DetallePrestamos
(
    IdDetalle INT IDENTITY(1,1) NOT NULL,
    IdPrestamo INT NOT NULL,
    IdLibro INT NOT NULL,
    FechaDevolucion DATETIME2 NULL,

    CONSTRAINT PK_DetallePrestamos
        PRIMARY KEY (IdDetalle),

    CONSTRAINT FK_DetallePrestamos_Prestamos
        FOREIGN KEY (IdPrestamo)
        REFERENCES dbo.Prestamos(IdPrestamo),

    CONSTRAINT FK_DetallePrestamos_Libros
        FOREIGN KEY (IdLibro)
        REFERENCES dbo.Libros(IdLibro)
);
GO

-- ============================================================
-- DATOS: AUTORES
-- ============================================================

SET IDENTITY_INSERT dbo.Autores ON;

INSERT INTO dbo.Autores
    (IdAutor, Codigo, Nombre, Apellidos, Nacionalidad, FechaNacimiento)
VALUES
    (1, 'AUT001', 'Robert', 'Martin', 'Estadounidense', '1952-12-05'),
    (2, 'AUT002', 'Martin', 'Fowler', 'Británico', '1963-12-18'),
    (3, 'AUT003', 'Andrew', 'Tanenbaum', 'Estadounidense', '1944-03-16');

SET IDENTITY_INSERT dbo.Autores OFF;
GO

-- ============================================================
-- DATOS: CATEGORIAS
-- ============================================================

SET IDENTITY_INSERT dbo.Categorias ON;

INSERT INTO dbo.Categorias
    (IdCategoria, Nombre)
VALUES
    (1, 'Programación'),
    (2, 'Bases de datos'),
    (3, 'Redes'),
    (4, 'Matemáticas'),
    (5, 'Electrónica'),
    (6, 'Inteligencia Artificial'),
    (7, 'Otros');

SET IDENTITY_INSERT dbo.Categorias OFF;
GO

-- ============================================================
-- DATOS: LIBROS
-- ============================================================

SET IDENTITY_INSERT dbo.Libros ON;

INSERT INTO dbo.Libros
    (IdLibro, Codigo, ISBN, Titulo, IdAutor, IdCategoria, Cantidad, Disponible)
VALUES
    (1, 'LIB001', '9780132350884', 'Clean Code', 1, 1, 5, 4),
    (2, 'LIB002', '9780201485677', 'Refactoring', 2, 1, 4, 4),
    (3, 'LIB003', '9780132126953', 'Computer Networks', 3, 3, 3, 3);

SET IDENTITY_INSERT dbo.Libros OFF;
GO

-- ============================================================
-- DATOS: USUARIOS
-- ============================================================

SET IDENTITY_INSERT dbo.Usuarios ON;

INSERT INTO dbo.Usuarios
    (IdUsuario, Documento, Nombre, Apellidos, Telefono, Correo, ProgramaAcademico)
VALUES
    (1, '1001001001', 'Carlos', 'Rodríguez', '3001234567',
     'carlos.rodriguez@universidad.edu.co', 'Ingeniería de Sistemas'),

    (2, '1001001002', 'Laura', 'Martínez', '3012345678',
     'laura.martinez@universidad.edu.co', 'Ingeniería Electrónica'),

    (3, '1001001003', 'Andrés', 'Gómez', '3023456789',
     'andres.gomez@universidad.edu.co', 'Matemáticas');

SET IDENTITY_INSERT dbo.Usuarios OFF;
GO

-- ============================================================
-- DATOS: PRESTAMOS
-- ============================================================

SET IDENTITY_INSERT dbo.Prestamos ON;

INSERT INTO dbo.Prestamos
    (IdPrestamo, IdUsuario, FechaPrestamo, FechaDevolucionEsperada, Estado)
VALUES
    (1, 1, '2026-09-02T12:26:21.2100000', '2026-09-09', 'Activo'),
    (2, 3, '2026-09-02T14:10:14.5800000', '2026-09-09', 'Devuelto');

SET IDENTITY_INSERT dbo.Prestamos OFF;
GO

-- ============================================================
-- DATOS: DETALLE DE PRESTAMOS
-- ============================================================

SET IDENTITY_INSERT dbo.DetallePrestamos ON;

INSERT INTO dbo.DetallePrestamos
    (IdDetalle, IdPrestamo, IdLibro, FechaDevolucion)
VALUES
    (1, 1, 1, NULL),
    (2, 2, 1, '2026-09-02T20:23:52.0033333');

SET IDENTITY_INSERT dbo.DetallePrestamos OFF;
GO

-- ============================================================
-- CONSULTA DE VERIFICACION
-- ============================================================

SELECT * FROM dbo.Autores;
SELECT * FROM dbo.Categorias;
SELECT * FROM dbo.Libros;
SELECT * FROM dbo.Usuarios;
SELECT * FROM dbo.Prestamos;
SELECT * FROM dbo.DetallePrestamos;
GO
