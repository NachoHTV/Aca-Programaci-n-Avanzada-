using System;
using System.Drawing;
using System.Windows.Forms;

namespace Biblioteca.Presentacion
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            ConfigurarFormulario();
            CrearInterfaz();
        }

        private void ConfigurarFormulario()
        {
            Text = "Sistema de Biblioteca";

            StartPosition =
                FormStartPosition.CenterScreen;

            Size =
                new Size(1000, 720);

            MinimumSize =
                new Size(900, 650);

            BackColor =
                Color.White;
        }

        private void CrearInterfaz()
        {
            Label titulo = new Label();

            titulo.Text =
                "SISTEMA DE BIBLIOTECA";

            titulo.Font =
                new Font(
                    "Segoe UI",
                    26,
                    FontStyle.Bold);

            titulo.ForeColor =
                Color.FromArgb(31, 78, 121);

            titulo.AutoSize = true;

            titulo.Location =
                new Point(285, 40);

            Controls.Add(titulo);

            Label subtitulo = new Label();

            subtitulo.Text =
                "Gesti�n de libros, usuarios y pr�stamos";

            subtitulo.Font =
                new Font(
                    "Segoe UI",
                    12);

            subtitulo.ForeColor =
                Color.Gray;

            subtitulo.AutoSize = true;

            subtitulo.Location =
                new Point(335, 90);

            Controls.Add(subtitulo);

            Panel linea = new Panel();

            linea.BackColor =
                Color.FromArgb(31, 78, 121);

            linea.Size =
                new Size(800, 3);

            linea.Location =
                new Point(100, 125);

            Controls.Add(linea);

            // ==============================
            // PRIMERA FILA
            // ==============================

            CrearBoton(
                "Autores",
                170,
                160,
                250,
                65,
                MostrarAutores);

            CrearBoton(
                "Categor�as",
                480,
                160,
                250,
                65,
                MostrarCategorias);

            // ==============================
            // SEGUNDA FILA
            // ==============================

            CrearBoton(
                "Libros",
                170,
                250,
                250,
                65,
                MostrarLibros);

            CrearBoton(
                "Usuarios",
                480,
                250,
                250,
                65,
                MostrarUsuarios);

            // ==============================
            // TERCERA FILA
            // ==============================

            CrearBoton(
                "Pr�stamos",
                170,
                340,
                250,
                65,
                MostrarPrestamos);

            CrearBoton(
                "Devoluciones",
                480,
                340,
                250,
                65,
                MostrarDevoluciones);

            // ==============================
            // CONSULTAS
            // ==============================

            CrearBoton(
                "Consultas",
                325,
                430,
                250,
                65,
                MostrarConsultas);

            Label pie = new Label();

            pie.Text =
                "Sistema de gesti�n bibliotecaria";

            pie.Font =
                new Font(
                    "Segoe UI",
                    9);

            pie.ForeColor =
                Color.Gray;

            pie.AutoSize = true;

            pie.Location =
                new Point(400, 580);

            Controls.Add(pie);
        }

        private void CrearBoton(
            string texto,
            int x,
            int y,
            int ancho,
            int alto,
            EventHandler evento)
        {
            Button boton = new Button();

            boton.Text =
                texto;

            boton.Font =
                new Font(
                    "Segoe UI",
                    12,
                    FontStyle.Bold);

            boton.Size =
                new Size(ancho, alto);

            boton.Location =
                new Point(x, y);

            boton.BackColor =
                Color.FromArgb(31, 78, 121);

            boton.ForeColor =
                Color.White;

            boton.FlatStyle =
                FlatStyle.Flat;

            boton.FlatAppearance.BorderSize =
                0;

            boton.Cursor =
                Cursors.Hand;

            boton.Click += evento;

            Controls.Add(boton);
        }

        // ==============================
        // AUTORES
        // ==============================

        private void MostrarAutores(
            object? sender,
            EventArgs e)
        {
            FrmAutores formulario =
                new FrmAutores();

            formulario.ShowDialog();
        }

        // ==============================
        // CATEGOR�AS
        // ==============================

        private void MostrarCategorias(
            object? sender,
            EventArgs e)
        {
            FrmCategorias formulario =
                new FrmCategorias();

            formulario.ShowDialog();
        }

        // ==============================
        // LIBROS
        // ==============================

        private void MostrarLibros(
            object? sender,
            EventArgs e)
        {
            FrmLibros formulario =
                new FrmLibros();

            formulario.ShowDialog();
        }

        // ==============================
        // USUARIOS
        // ==============================

        private void MostrarUsuarios(
            object? sender,
            EventArgs e)
        {
            FrmUsuarios formulario =
                new FrmUsuarios();

            formulario.ShowDialog();
        }

        // ==============================
        // PR�STAMOS
        // ==============================

        private void MostrarPrestamos(
            object? sender,
            EventArgs e)
        {
            FrmPrestamos formulario =
                new FrmPrestamos();

            formulario.ShowDialog();
        }

        // ==============================
        // DEVOLUCIONES
        // ==============================

        private void MostrarDevoluciones(
            object? sender,
            EventArgs e)
        {
            FrmDevoluciones formulario =
                new FrmDevoluciones();

            formulario.ShowDialog();
        }

        // ==============================
        // CONSULTAS
        // ==============================

        private void MostrarConsultas(
            object? sender,
            EventArgs e)
        {
            FrmConsultas formulario =
                new FrmConsultas();

            formulario.ShowDialog();
        }
    }
}