﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Biblioteca.Entidades;
using Biblioteca.Negocio;

namespace Biblioteca.Presentacion
{
    public class FrmLibros : Form
    {
        private readonly LibroNegocio negocio;
        private readonly AutorNegocio autorNegocio;
        private readonly CategoriaNegocio categoriaNegocio;

        private int idLibroSeleccionado = 0;

        private DataGridView dgvLibros = null!;

        private TextBox txtCodigo = null!;
        private TextBox txtISBN = null!;
        private TextBox txtTitulo = null!;

        private ComboBox cboAutor = null!;
        private ComboBox cboCategoria = null!;

        private NumericUpDown nudCantidad = null!;
        private NumericUpDown nudDisponible = null!;

        private TextBox txtBuscar = null!;
        private ComboBox cboBuscarPor = null!;

        private Button btnNuevo = null!;
        private Button btnGuardar = null!;
        private Button btnEditar = null!;
        private Button btnEliminar = null!;
        private Button btnActualizar = null!;
        private Button btnBuscar = null!;
        private Button btnMostrarTodos = null!;

        public FrmLibros()
        {
            negocio = new LibroNegocio();
            autorNegocio = new AutorNegocio();
            categoriaNegocio = new CategoriaNegocio();

            ConfigurarFormulario();
            CrearInterfaz();
            CargarAutores();
            CargarCategorias();
            CargarLibros();
        }

        private void ConfigurarFormulario()
        {
            Text = "Gestión de Libros";
            StartPosition = FormStartPosition.CenterScreen;
            Size = new Size(1150, 800);
            MinimumSize = new Size(1050, 700);
            BackColor = Color.White;
        }

        private void CrearInterfaz()
        {
            Label titulo = new Label();

            titulo.Text = "GESTIÓN DE LIBROS";
            titulo.Font = new Font(
                "Segoe UI",
                24,
                FontStyle.Bold);

            titulo.ForeColor =
                Color.FromArgb(31, 78, 121);

            titulo.AutoSize = true;
            titulo.Location =
                new Point(430, 25);

            Controls.Add(titulo);

            // ==============================
            // CAMPOS
            // ==============================

            CrearEtiqueta(
                "Código:",
                50,
                100);

            txtCodigo = CrearTextBox(
                160,
                95,
                250);

            CrearEtiqueta(
                "ISBN:",
                50,
                150);

            txtISBN = CrearTextBox(
                160,
                145,
                250);

            CrearEtiqueta(
                "Título:",
                50,
                200);

            txtTitulo = CrearTextBox(
                160,
                195,
                250);

            CrearEtiqueta(
                "Autor:",
                50,
                250);

            cboAutor = CrearComboBox(
                160,
                245,
                250);

            CrearEtiqueta(
                "Categoría:",
                50,
                300);

            cboCategoria = CrearComboBox(
                160,
                295,
                250);

            CrearEtiqueta(
                "Cantidad:",
                480,
                100);

            nudCantidad = CrearNumerico(
                590,
                95,
                180);

            CrearEtiqueta(
                "Disponible:",
                480,
                150);

            nudDisponible = CrearNumerico(
                590,
                145,
                180);

            // ==============================
            // BOTONES CRUD
            // ==============================

            btnNuevo = CrearBoton(
                "Nuevo",
                810,
                95,
                120,
                40,
                NuevoLibro);

            btnGuardar = CrearBoton(
                "Guardar",
                940,
                95,
                120,
                40,
                GuardarLibro);

            btnEditar = CrearBoton(
                "Editar",
                810,
                150,
                120,
                40,
                EditarLibro);

            btnEliminar = CrearBoton(
                "Eliminar",
                940,
                150,
                120,
                40,
                EliminarLibro);

            btnActualizar = CrearBoton(
                "Actualizar",
                810,
                205,
                250,
                40,
                ActualizarLista);

            // ==============================
            // BÚSQUEDA
            // ==============================

            Label tituloBusqueda = new Label();

            tituloBusqueda.Text =
                "BUSCAR LIBRO";

            tituloBusqueda.Font =
                new Font(
                    "Segoe UI",
                    12,
                    FontStyle.Bold);

            tituloBusqueda.ForeColor =
                Color.FromArgb(31, 78, 121);

            tituloBusqueda.AutoSize = true;

            tituloBusqueda.Location =
                new Point(50, 350);

            Controls.Add(tituloBusqueda);

            CrearEtiqueta(
                "Buscar por:",
                50,
                390);

            cboBuscarPor = new ComboBox();

            cboBuscarPor.Location =
                new Point(160, 385);

            cboBuscarPor.Size =
                new Size(180, 30);

            cboBuscarPor.Font =
                new Font("Segoe UI", 10);

            cboBuscarPor.DropDownStyle =
                ComboBoxStyle.DropDownList;

            cboBuscarPor.Items.Add("Código");
            cboBuscarPor.Items.Add("Título");
            cboBuscarPor.Items.Add("Autor");
            cboBuscarPor.Items.Add("Categoría");

            cboBuscarPor.SelectedIndex = 0;

            Controls.Add(cboBuscarPor);

            txtBuscar = CrearTextBox(
                355,
                385,
                280);

            txtBuscar.KeyDown +=
                TxtBuscar_KeyDown;

            btnBuscar = CrearBoton(
                "Buscar",
                650,
                380,
                120,
                40,
                BuscarLibros);

            btnMostrarTodos = CrearBoton(
                "Mostrar todos",
                780,
                380,
                150,
                40,
                MostrarTodos);

            // ==============================
            // TABLA
            // ==============================

            dgvLibros = new DataGridView();

            dgvLibros.Location =
                new Point(50, 450);

            dgvLibros.Size =
                new Size(1010, 250);

            dgvLibros.ReadOnly = true;

            dgvLibros.AllowUserToAddRows =
                false;

            dgvLibros.AllowUserToDeleteRows =
                false;

            dgvLibros.SelectionMode =
                DataGridViewSelectionMode.FullRowSelect;

            dgvLibros.MultiSelect = false;

            dgvLibros.AutoSizeColumnsMode =
                DataGridViewAutoSizeColumnsMode.Fill;

            dgvLibros.RowHeadersVisible = false;

            dgvLibros.Columns.Add(
                "IdLibro",
                "ID");

            dgvLibros.Columns.Add(
                "Codigo",
                "Código");

            dgvLibros.Columns.Add(
                "ISBN",
                "ISBN");

            dgvLibros.Columns.Add(
                "Titulo",
                "Título");

            dgvLibros.Columns.Add(
                "Autor",
                "Autor");

            dgvLibros.Columns.Add(
                "Categoria",
                "Categoría");

            dgvLibros.Columns.Add(
                "Cantidad",
                "Cantidad");

            dgvLibros.Columns.Add(
                "Disponible",
                "Disponible");

            dgvLibros.CellClick +=
                SeleccionarLibro;

            Controls.Add(dgvLibros);
        }

        // ==============================
        // CONTROLES
        // ==============================

        private void CrearEtiqueta(
            string texto,
            int x,
            int y)
        {
            Label etiqueta = new Label();

            etiqueta.Text = texto;

            etiqueta.Font =
                new Font(
                    "Segoe UI",
                    10,
                    FontStyle.Bold);

            etiqueta.AutoSize = true;

            etiqueta.Location =
                new Point(x, y + 5);

            Controls.Add(etiqueta);
        }

        private TextBox CrearTextBox(
            int x,
            int y,
            int ancho)
        {
            TextBox texto =
                new TextBox();

            texto.Size =
                new Size(ancho, 30);

            texto.Location =
                new Point(x, y);

            texto.Font =
                new Font(
                    "Segoe UI",
                    10);

            Controls.Add(texto);

            return texto;
        }

        private ComboBox CrearComboBox(
            int x,
            int y,
            int ancho)
        {
            ComboBox combo =
                new ComboBox();

            combo.Size =
                new Size(ancho, 30);

            combo.Location =
                new Point(x, y);

            combo.Font =
                new Font(
                    "Segoe UI",
                    10);

            combo.DropDownStyle =
                ComboBoxStyle.DropDownList;

            Controls.Add(combo);

            return combo;
        }

        private NumericUpDown CrearNumerico(
            int x,
            int y,
            int ancho)
        {
            NumericUpDown numero =
                new NumericUpDown();

            numero.Size =
                new Size(ancho, 30);

            numero.Location =
                new Point(x, y);

            numero.Font =
                new Font(
                    "Segoe UI",
                    10);

            numero.Minimum = 0;
            numero.Maximum = 10000;

            Controls.Add(numero);

            return numero;
        }

        private Button CrearBoton(
            string texto,
            int x,
            int y,
            int ancho,
            int alto,
            EventHandler evento)
        {
            Button boton =
                new Button();

            boton.Text = texto;

            boton.Font =
                new Font(
                    "Segoe UI",
                    10,
                    FontStyle.Bold);

            boton.Size =
                new Size(ancho, alto);

            boton.Location =
                new Point(x, y);

            boton.BackColor =
                Color.FromArgb(31, 78, 121);

            boton.ForeColor =
                Color.White;

            boton.FlatStyle =
                FlatStyle.Flat;

            boton.FlatAppearance.BorderSize = 0;

            boton.Cursor =
                Cursors.Hand;

            boton.Click += evento;

            Controls.Add(boton);

            return boton;
        }

        // ==============================
        // AUTORES
        // ==============================

        private void CargarAutores()
        {
            try
            {
                List<Autor> autores =
                    autorNegocio.Listar();

                cboAutor.DataSource = null;

                cboAutor.DataSource =
                    autores;

                cboAutor.DisplayMember =
                    "Apellidos";

                cboAutor.ValueMember =
                    "IdAutor";

                cboAutor.Format +=
                    FormatearAutor;
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "No se pudieron cargar los autores.\n\n"
                    + ex.Message,
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void FormatearAutor(
            object? sender,
            ListControlConvertEventArgs e)
        {
            if (e.ListItem is Autor autor)
            {
                e.Value =
                    autor.Nombre + " " +
                    autor.Apellidos;
            }
        }

        // ==============================
        // CATEGORÍAS
        // ==============================

        private void CargarCategorias()
        {
            try
            {
                List<Categoria> categorias =
                    categoriaNegocio.Listar();

                cboCategoria.DataSource = null;

                cboCategoria.DataSource =
                    categorias;

                cboCategoria.DisplayMember =
                    "Nombre";

                cboCategoria.ValueMember =
                    "IdCategoria";
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "No se pudieron cargar las categorías.\n\n"
                    + ex.Message,
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        // ==============================
        // LIBROS
        // ==============================

        private void CargarLibros()
        {
            try
            {
                List<Libro> libros =
                    negocio.Listar();

                MostrarLibrosEnTabla(libros);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "No se pudieron cargar los libros.\n\n"
                    + ex.Message,
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void MostrarLibrosEnTabla(
            List<Libro> libros)
        {
            List<Autor> autores =
                autorNegocio.Listar();

            List<Categoria> categorias =
                categoriaNegocio.Listar();

            dgvLibros.Rows.Clear();

            foreach (Libro libro in libros)
            {
                Autor? autor =
                    autores.FirstOrDefault(
                        a => a.IdAutor ==
                             libro.IdAutor);

                Categoria? categoria =
                    categorias.FirstOrDefault(
                        c => c.IdCategoria ==
                             libro.IdCategoria);

                int fila =
                    dgvLibros.Rows.Add();

                dgvLibros.Rows[fila]
                    .Cells["IdLibro"].Value =
                    libro.IdLibro;

                dgvLibros.Rows[fila]
                    .Cells["Codigo"].Value =
                    libro.Codigo;

                dgvLibros.Rows[fila]
                    .Cells["ISBN"].Value =
                    libro.ISBN;

                dgvLibros.Rows[fila]
                    .Cells["Titulo"].Value =
                    libro.Titulo;

                dgvLibros.Rows[fila]
                    .Cells["Autor"].Value =
                    autor == null
                        ? "Sin autor"
                        : autor.Nombre + " " +
                          autor.Apellidos;

                dgvLibros.Rows[fila]
                    .Cells["Categoria"].Value =
                    categoria == null
                        ? "Sin categoría"
                        : categoria.Nombre;

                dgvLibros.Rows[fila]
                    .Cells["Cantidad"].Value =
                    libro.Cantidad;

                dgvLibros.Rows[fila]
                    .Cells["Disponible"].Value =
                    libro.Disponible;

                dgvLibros.Rows[fila].Tag =
                    libro;
            }
        }

        // ==============================
        // BÚSQUEDA
        // ==============================

        private void BuscarLibros(
            object? sender,
            EventArgs e)
        {
            try
            {
                string texto =
                    txtBuscar.Text.Trim();

                if (string.IsNullOrWhiteSpace(texto))
                {
                    MessageBox.Show(
                        "Escriba un valor para realizar la búsqueda.",
                        "Biblioteca",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);

                    txtBuscar.Focus();

                    return;
                }

                List<Libro> libros =
                    negocio.Listar();

                List<Autor> autores =
                    autorNegocio.Listar();

                List<Categoria> categorias =
                    categoriaNegocio.Listar();

                string criterio =
                    cboBuscarPor.SelectedItem?.ToString()
                    ?? "Código";

                IEnumerable<Libro> resultado =
                    libros;

                if (criterio == "Código")
                {
                    resultado =
                        libros.Where(
                            l => l.Codigo
                                .Contains(
                                    texto,
                                    StringComparison.OrdinalIgnoreCase));
                }
                else if (criterio == "Título")
                {
                    resultado =
                        libros.Where(
                            l => l.Titulo
                                .Contains(
                                    texto,
                                    StringComparison.OrdinalIgnoreCase));
                }
                else if (criterio == "Autor")
                {
                    resultado =
                        libros.Where(
                            l =>
                            {
                                Autor? autor =
                                    autores.FirstOrDefault(
                                        a => a.IdAutor ==
                                             l.IdAutor);

                                string nombreAutor =
                                    autor == null
                                        ? ""
                                        : autor.Nombre +
                                          " " +
                                          autor.Apellidos;

                                return nombreAutor.Contains(
                                    texto,
                                    StringComparison.OrdinalIgnoreCase);
                            });
                }
                else if (criterio == "Categoría")
                {
                    resultado =
                        libros.Where(
                            l =>
                            {
                                Categoria? categoria =
                                    categorias.FirstOrDefault(
                                        c => c.IdCategoria ==
                                             l.IdCategoria);

                                string nombreCategoria =
                                    categoria == null
                                        ? ""
                                        : categoria.Nombre;

                                return nombreCategoria.Contains(
                                    texto,
                                    StringComparison.OrdinalIgnoreCase);
                            });
                }

                List<Libro> librosEncontrados =
                    resultado.ToList();

                MostrarLibrosEnTabla(
                    librosEncontrados);

                if (librosEncontrados.Count == 0)
                {
                    MessageBox.Show(
                        "No se encontraron libros con ese criterio.",
                        "Biblioteca",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "No se pudo realizar la búsqueda.\n\n"
                    + ex.Message,
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void MostrarTodos(
            object? sender,
            EventArgs e)
        {
            txtBuscar.Clear();
            CargarLibros();
        }

        private void TxtBuscar_KeyDown(
            object? sender,
            KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                BuscarLibros(
                    sender,
                    EventArgs.Empty);

                e.SuppressKeyPress = true;
            }
        }

        // ==============================
        // SELECCIONAR LIBRO
        // ==============================

        private void SeleccionarLibro(
            object? sender,
            DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
                return;

            DataGridViewRow fila =
                dgvLibros.Rows[e.RowIndex];

            if (fila.Tag is Libro libro)
            {
                idLibroSeleccionado =
                    libro.IdLibro;

                txtCodigo.Text =
                    libro.Codigo;

                txtISBN.Text =
                    libro.ISBN;

                txtTitulo.Text =
                    libro.Titulo;

                nudCantidad.Value =
                    libro.Cantidad;

                nudDisponible.Value =
                    libro.Disponible;

                cboAutor.SelectedValue =
                    libro.IdAutor;

                cboCategoria.SelectedValue =
                    libro.IdCategoria;
            }
        }

        // ==============================
        // NUEVO
        // ==============================

        private void NuevoLibro(
            object? sender,
            EventArgs e)
        {
            LimpiarFormulario();
        }

        // ==============================
        // GUARDAR
        // ==============================

        private void GuardarLibro(
            object? sender,
            EventArgs e)
        {
            try
            {
                if (cboAutor.SelectedValue == null)
                {
                    MessageBox.Show(
                        "Debe seleccionar un autor.",
                        "Biblioteca",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);

                    return;
                }

                if (cboCategoria.SelectedValue == null)
                {
                    MessageBox.Show(
                        "Debe seleccionar una categoría.",
                        "Biblioteca",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);

                    return;
                }

                Libro libro =
                    new Libro
                    {
                        Codigo =
                            txtCodigo.Text.Trim(),

                        ISBN =
                            txtISBN.Text.Trim(),

                        Titulo =
                            txtTitulo.Text.Trim(),

                        IdAutor =
                            Convert.ToInt32(
                                cboAutor.SelectedValue),

                        IdCategoria =
                            Convert.ToInt32(
                                cboCategoria.SelectedValue),

                        Cantidad =
                            Convert.ToInt32(
                                nudCantidad.Value),

                        Disponible =
                            Convert.ToInt32(
                                nudCantidad.Value)
                    };

                negocio.Registrar(libro);

                MessageBox.Show(
                    "Libro registrado correctamente.",
                    "Biblioteca",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                LimpiarFormulario();

                CargarLibros();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    ex.Message,
                    "No se pudo registrar el libro",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
        }

        // ==============================
        // EDITAR
        // ==============================

        private void EditarLibro(
            object? sender,
            EventArgs e)
        {
            try
            {
                if (idLibroSeleccionado <= 0)
                {
                    MessageBox.Show(
                        "Seleccione un libro de la tabla.",
                        "Biblioteca",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);

                    return;
                }

                if (cboAutor.SelectedValue == null ||
                    cboCategoria.SelectedValue == null)
                {
                    MessageBox.Show(
                        "Debe seleccionar autor y categoría.",
                        "Biblioteca",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);

                    return;
                }

                Libro libro =
                    new Libro
                    {
                        IdLibro =
                            idLibroSeleccionado,

                        Codigo =
                            txtCodigo.Text.Trim(),

                        ISBN =
                            txtISBN.Text.Trim(),

                        Titulo =
                            txtTitulo.Text.Trim(),

                        IdAutor =
                            Convert.ToInt32(
                                cboAutor.SelectedValue),

                        IdCategoria =
                            Convert.ToInt32(
                                cboCategoria.SelectedValue),

                        Cantidad =
                            Convert.ToInt32(
                                nudCantidad.Value),

                        Disponible =
                            Convert.ToInt32(
                                nudDisponible.Value)
                    };

                negocio.Actualizar(libro);

                MessageBox.Show(
                    "Libro actualizado correctamente.",
                    "Biblioteca",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                LimpiarFormulario();

                CargarLibros();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    ex.Message,
                    "No se pudo actualizar el libro",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
        }

        // ==============================
        // ELIMINAR
        // ==============================

        private void EliminarLibro(
            object? sender,
            EventArgs e)
        {
            try
            {
                if (idLibroSeleccionado <= 0)
                {
                    MessageBox.Show(
                        "Seleccione un libro de la tabla.",
                        "Biblioteca",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);

                    return;
                }

                DialogResult respuesta =
                    MessageBox.Show(
                        "¿Está seguro de eliminar el libro seleccionado?",
                        "Confirmar eliminación",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Question);

                if (respuesta !=
                    DialogResult.Yes)
                {
                    return;
                }

                negocio.Eliminar(
                    idLibroSeleccionado);

                MessageBox.Show(
                    "Libro eliminado correctamente.",
                    "Biblioteca",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                LimpiarFormulario();

                CargarLibros();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    ex.Message,
                    "No se pudo eliminar el libro",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
        }

        // ==============================
        // ACTUALIZAR
        // ==============================

        private void ActualizarLista(
            object? sender,
            EventArgs e)
        {
            CargarAutores();
            CargarCategorias();
            CargarLibros();
        }

        // ==============================
        // LIMPIAR
        // ==============================

        private void LimpiarFormulario()
        {
            idLibroSeleccionado = 0;

            txtCodigo.Clear();
            txtISBN.Clear();
            txtTitulo.Clear();

            nudCantidad.Value = 0;
            nudDisponible.Value = 0;

            if (cboAutor.Items.Count > 0)
                cboAutor.SelectedIndex = 0;

            if (cboCategoria.Items.Count > 0)
                cboCategoria.SelectedIndex = 0;

            dgvLibros.ClearSelection();

            txtCodigo.Focus();
        }
    }
}