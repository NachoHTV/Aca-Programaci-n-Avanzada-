﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Biblioteca.Entidades;
using Biblioteca.Negocio;

namespace Biblioteca.Presentacion
{
    public class FrmAutores : Form
    {
        // =========================
        // VARIABLES
        // =========================

        private readonly AutorNegocio negocio;

        private int idAutorSeleccionado = 0;

        // =========================
        // CONTROLES
        // =========================

        private DataGridView dgvAutores = null!;

        private TextBox txtCodigo = null!;
        private TextBox txtNombre = null!;
        private TextBox txtApellidos = null!;
        private TextBox txtNacionalidad = null!;

        private DateTimePicker dtpFechaNacimiento = null!;

        private Button btnNuevo = null!;
        private Button btnGuardar = null!;
        private Button btnEditar = null!;
        private Button btnEliminar = null!;
        private Button btnActualizar = null!;


        // =========================
        // CONSTRUCTOR
        // =========================

        public FrmAutores()
        {
            negocio = new AutorNegocio();

            ConfigurarFormulario();

            CrearInterfaz();

            CargarAutores();
        }


        // =========================
        // CONFIGURAR FORMULARIO
        // =========================

        private void ConfigurarFormulario()
        {
            Text = "Gestión de Autores";

            StartPosition =
                FormStartPosition.CenterScreen;

            Size =
                new Size(1050, 700);

            MinimumSize =
                new Size(950, 600);

            BackColor =
                Color.White;
        }


        // =========================
        // CREAR INTERFAZ
        // =========================

        private void CrearInterfaz()
        {
            // =========================
            // TÍTULO
            // =========================

            Label titulo =
                new Label();

            titulo.Text =
                "GESTIÓN DE AUTORES";

            titulo.Font =
                new Font(
                    "Segoe UI",
                    24,
                    FontStyle.Bold);

            titulo.ForeColor =
                Color.FromArgb(
                    31,
                    78,
                    121);

            titulo.AutoSize =
                true;

            titulo.Location =
                new Point(350, 25);

            Controls.Add(titulo);


            // =========================
            // CÓDIGO
            // =========================

            CrearEtiqueta(
                "Código:",
                60,
                100);

            txtCodigo =
                CrearTextBox(
                    180,
                    95,
                    220);


            // =========================
            // NOMBRE
            // =========================

            CrearEtiqueta(
                "Nombre:",
                60,
                150);

            txtNombre =
                CrearTextBox(
                    180,
                    145,
                    220);


            // =========================
            // APELLIDOS
            // =========================

            CrearEtiqueta(
                "Apellidos:",
                60,
                200);

            txtApellidos =
                CrearTextBox(
                    180,
                    195,
                    220);


            // =========================
            // NACIONALIDAD
            // =========================

            CrearEtiqueta(
                "Nacionalidad:",
                60,
                250);

            txtNacionalidad =
                CrearTextBox(
                    180,
                    245,
                    220);


            // =========================
            // FECHA NACIMIENTO
            // =========================

            CrearEtiqueta(
                "Fecha nacimiento:",
                60,
                300);

            dtpFechaNacimiento =
                new DateTimePicker();

            dtpFechaNacimiento.Format =
                DateTimePickerFormat.Short;

            dtpFechaNacimiento.Size =
                new Size(220, 30);

            dtpFechaNacimiento.Location =
                new Point(180, 295);

            Controls.Add(
                dtpFechaNacimiento);


            // =========================
            // BOTÓN NUEVO
            // =========================

            btnNuevo =
                CrearBoton(
                    "Nuevo",
                    450,
                    95,
                    110,
                    NuevoAutor);


            // =========================
            // BOTÓN GUARDAR
            // =========================

            btnGuardar =
                CrearBoton(
                    "Guardar",
                    570,
                    95,
                    110,
                    GuardarAutor);


            // =========================
            // BOTÓN EDITAR
            // =========================

            btnEditar =
                CrearBoton(
                    "Editar",
                    690,
                    95,
                    110,
                    EditarAutor);


            // =========================
            // BOTÓN ELIMINAR
            // =========================

            btnEliminar =
                CrearBoton(
                    "Eliminar",
                    810,
                    95,
                    110,
                    EliminarAutor);


            // =========================
            // BOTÓN ACTUALIZAR
            // =========================

            btnActualizar =
                CrearBoton(
                    "Actualizar",
                    450,
                    145,
                    470,
                    ActualizarLista);


            // =========================
            // TABLA
            // =========================

            dgvAutores =
                new DataGridView();

            dgvAutores.Location =
                new Point(60, 360);

            dgvAutores.Size =
                new Size(870, 240);

            dgvAutores.AutoGenerateColumns =
                true;

            dgvAutores.ReadOnly =
                true;

            dgvAutores.AllowUserToAddRows =
                false;

            dgvAutores.AllowUserToDeleteRows =
                false;

            dgvAutores.SelectionMode =
                DataGridViewSelectionMode.FullRowSelect;

            dgvAutores.MultiSelect =
                false;

            dgvAutores.AutoSizeColumnsMode =
                DataGridViewAutoSizeColumnsMode.Fill;

            dgvAutores.CellClick +=
                SeleccionarAutor;

            Controls.Add(
                dgvAutores);
        }


        // =========================
        // CREAR ETIQUETA
        // =========================

        private void CrearEtiqueta(
            string texto,
            int x,
            int y)
        {
            Label etiqueta =
                new Label();

            etiqueta.Text =
                texto;

            etiqueta.Font =
                new Font(
                    "Segoe UI",
                    10,
                    FontStyle.Bold);

            etiqueta.AutoSize =
                true;

            etiqueta.Location =
                new Point(
                    x,
                    y + 5);

            Controls.Add(
                etiqueta);
        }


        // =========================
        // CREAR TEXTBOX
        // =========================

        private TextBox CrearTextBox(
            int x,
            int y,
            int ancho)
        {
            TextBox texto =
                new TextBox();

            texto.Size =
                new Size(
                    ancho,
                    30);

            texto.Location =
                new Point(
                    x,
                    y);

            texto.Font =
                new Font(
                    "Segoe UI",
                    10);

            Controls.Add(
                texto);

            return texto;
        }


        // =========================
        // CREAR BOTÓN
        // =========================

        private Button CrearBoton(
            string texto,
            int x,
            int y,
            int ancho,
            EventHandler evento)
        {
            Button boton =
                new Button();

            boton.Text =
                texto;

            boton.Font =
                new Font(
                    "Segoe UI",
                    10,
                    FontStyle.Bold);

            boton.Size =
                new Size(
                    ancho,
                    40);

            boton.Location =
                new Point(
                    x,
                    y);

            boton.BackColor =
                Color.FromArgb(
                    31,
                    78,
                    121);

            boton.ForeColor =
                Color.White;

            boton.FlatStyle =
                FlatStyle.Flat;

            boton.FlatAppearance.BorderSize =
                0;

            boton.Cursor =
                Cursors.Hand;

            boton.Click +=
                evento;

            Controls.Add(
                boton);

            return boton;
        }


        // =========================
        // CARGAR AUTORES
        // =========================

        private void CargarAutores()
        {
            try
            {
                dgvAutores.DataSource =
                    null;

                dgvAutores.DataSource =
                    negocio.Listar();

                if (dgvAutores.Columns["IdAutor"] != null)
                {
                    dgvAutores.Columns["IdAutor"]
                        .HeaderText = "ID";
                }

                if (dgvAutores.Columns["Codigo"] != null)
                {
                    dgvAutores.Columns["Codigo"]
                        .HeaderText = "Código";
                }

                if (dgvAutores.Columns["Nombre"] != null)
                {
                    dgvAutores.Columns["Nombre"]
                        .HeaderText = "Nombre";
                }

                if (dgvAutores.Columns["Apellidos"] != null)
                {
                    dgvAutores.Columns["Apellidos"]
                        .HeaderText = "Apellidos";
                }

                if (dgvAutores.Columns["Nacionalidad"] != null)
                {
                    dgvAutores.Columns["Nacionalidad"]
                        .HeaderText = "Nacionalidad";
                }

                if (dgvAutores.Columns["FechaNacimiento"] != null)
                {
                    dgvAutores.Columns["FechaNacimiento"]
                        .HeaderText =
                            "Fecha nacimiento";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "No se pudieron cargar los autores.\n\n" +
                    ex.Message,
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }


        // =========================
        // SELECCIONAR AUTOR
        // =========================

        private void SeleccionarAutor(
            object? sender,
            DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
            {
                return;
            }

            DataGridViewRow fila =
                dgvAutores.Rows[e.RowIndex];

            if (fila.DataBoundItem is Autor autor)
            {
                idAutorSeleccionado =
                    autor.IdAutor;

                txtCodigo.Text =
                    autor.Codigo;

                txtNombre.Text =
                    autor.Nombre;

                txtApellidos.Text =
                    autor.Apellidos;

                txtNacionalidad.Text =
                    autor.Nacionalidad;

                if (autor.FechaNacimiento !=
                    DateTime.MinValue)
                {
                    dtpFechaNacimiento.Value =
                        autor.FechaNacimiento;
                }
            }
        }


        // =========================
        // NUEVO AUTOR
        // =========================

        private void NuevoAutor(
            object? sender,
            EventArgs e)
        {
            LimpiarFormulario();
        }


        // =========================
        // GUARDAR AUTOR
        // =========================

        private void GuardarAutor(
            object? sender,
            EventArgs e)
        {
            try
            {
                Autor autor =
                    new Autor();

                autor.Codigo =
                    txtCodigo.Text.Trim();

                autor.Nombre =
                    txtNombre.Text.Trim();

                autor.Apellidos =
                    txtApellidos.Text.Trim();

                autor.Nacionalidad =
                    txtNacionalidad.Text.Trim();

                autor.FechaNacimiento =
                    dtpFechaNacimiento.Value;

                negocio.Registrar(
                    autor);

                MessageBox.Show(
                    "Autor registrado correctamente.",
                    "Biblioteca",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                LimpiarFormulario();

                CargarAutores();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    ex.Message,
                    "No se pudo registrar el autor",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
        }


        // =========================
        // EDITAR AUTOR
        // =========================

        private void EditarAutor(
            object? sender,
            EventArgs e)
        {
            try
            {
                if (idAutorSeleccionado <= 0)
                {
                    MessageBox.Show(
                        "Seleccione un autor de la tabla.",
                        "Biblioteca",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);

                    return;
                }

                Autor autor =
                    new Autor();

                autor.IdAutor =
                    idAutorSeleccionado;

                autor.Codigo =
                    txtCodigo.Text.Trim();

                autor.Nombre =
                    txtNombre.Text.Trim();

                autor.Apellidos =
                    txtApellidos.Text.Trim();

                autor.Nacionalidad =
                    txtNacionalidad.Text.Trim();

                autor.FechaNacimiento =
                    dtpFechaNacimiento.Value;

                negocio.Actualizar(
                    autor);

                MessageBox.Show(
                    "Autor actualizado correctamente.",
                    "Biblioteca",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                LimpiarFormulario();

                CargarAutores();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    ex.Message,
                    "No se pudo actualizar el autor",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
        }


        // =========================
        // ELIMINAR AUTOR
        // =========================

        private void EliminarAutor(
            object? sender,
            EventArgs e)
        {
            try
            {
                if (idAutorSeleccionado <= 0)
                {
                    MessageBox.Show(
                        "Seleccione un autor de la tabla.",
                        "Biblioteca",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);

                    return;
                }

                DialogResult respuesta =
                    MessageBox.Show(
                        "¿Está seguro de eliminar " +
                        "el autor seleccionado?",
                        "Confirmar eliminación",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Question);

                if (respuesta !=
                    DialogResult.Yes)
                {
                    return;
                }

                negocio.Eliminar(
                    idAutorSeleccionado);

                MessageBox.Show(
                    "Autor eliminado correctamente.",
                    "Biblioteca",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                LimpiarFormulario();

                CargarAutores();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    ex.Message,
                    "No se pudo eliminar el autor",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
        }


        // =========================
        // ACTUALIZAR LISTA
        // =========================

        private void ActualizarLista(
            object? sender,
            EventArgs e)
        {
            CargarAutores();
        }


        // =========================
        // LIMPIAR FORMULARIO
        // =========================

        private void LimpiarFormulario()
        {
            idAutorSeleccionado = 0;

            txtCodigo.Clear();

            txtNombre.Clear();

            txtApellidos.Clear();

            txtNacionalidad.Clear();

            dtpFechaNacimiento.Value =
                DateTime.Today;

            dgvAutores.ClearSelection();

            txtCodigo.Focus();
        }
    }
}