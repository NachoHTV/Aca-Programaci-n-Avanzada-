﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Biblioteca.Entidades;
using Biblioteca.Negocio;

namespace Biblioteca.Presentacion
{
    public class FrmDevoluciones : Form
    {
        private readonly PrestamoNegocio negocio;
        private readonly UsuarioNegocio usuarioNegocio;
        private readonly LibroNegocio libroNegocio;

        private ComboBox cboPrestamo = null!;
        private DataGridView dgvDevoluciones = null!;

        private Button btnActualizar = null!;
        private Button btnDevolver = null!;

        private List<DetalleDevolucion> detalles =
            new List<DetalleDevolucion>();

        public FrmDevoluciones()
        {
            negocio = new PrestamoNegocio();
            usuarioNegocio = new UsuarioNegocio();
            libroNegocio = new LibroNegocio();

            ConfigurarFormulario();
            CrearInterfaz();
            CargarPrestamosActivos();
        }

        private void ConfigurarFormulario()
        {
            Text = "Gestión de Devoluciones";
            StartPosition = FormStartPosition.CenterScreen;
            Size = new Size(1150, 700);
            MinimumSize = new Size(1050, 600);
            BackColor = Color.White;
        }

        private void CrearInterfaz()
        {
            Label titulo = new Label();

            titulo.Text = "GESTIÓN DE DEVOLUCIONES";
            titulo.Font = new Font(
                "Segoe UI",
                24,
                FontStyle.Bold);

            titulo.ForeColor =
                Color.FromArgb(31, 78, 121);

            titulo.AutoSize = true;
            titulo.Location =
                new Point(370, 25);

            Controls.Add(titulo);

            // ==============================
            // PRÉSTAMO
            // ==============================

            CrearEtiqueta(
                "Préstamo:",
                60,
                105);

            cboPrestamo = new ComboBox();

            cboPrestamo.Location =
                new Point(170, 100);

            cboPrestamo.Size =
                new Size(650, 30);

            cboPrestamo.Font =
                new Font("Segoe UI", 10);

            cboPrestamo.DropDownStyle =
                ComboBoxStyle.DropDownList;

            cboPrestamo.SelectedIndexChanged +=
                SeleccionarPrestamo;

            Controls.Add(cboPrestamo);

            // ==============================
            // BOTONES
            // ==============================

            btnActualizar = CrearBoton(
                "Actualizar",
                850,
                95,
                120,
                40,
                ActualizarLista);

            btnDevolver = CrearBoton(
                "Registrar devolución",
                850,
                150,
                220,
                45,
                RegistrarDevolucion);

            // ==============================
            // INFORMACIÓN
            // ==============================

            Label informacion = new Label();

            informacion.Text =
                "Seleccione un préstamo y luego el libro que desea devolver.";

            informacion.Font =
                new Font(
                    "Segoe UI",
                    9,
                    FontStyle.Italic);

            informacion.ForeColor =
                Color.Gray;

            informacion.AutoSize = true;

            informacion.Location =
                new Point(170, 150);

            Controls.Add(informacion);

            // ==============================
            // TABLA
            // ==============================

            dgvDevoluciones =
                new DataGridView();

            dgvDevoluciones.Location =
                new Point(60, 230);

            dgvDevoluciones.Size =
                new Size(1010, 300);

            dgvDevoluciones.ReadOnly = true;

            dgvDevoluciones.AllowUserToAddRows =
                false;

            dgvDevoluciones.AllowUserToDeleteRows =
                false;

            dgvDevoluciones.SelectionMode =
                DataGridViewSelectionMode.FullRowSelect;

            dgvDevoluciones.MultiSelect = false;

            dgvDevoluciones.AutoSizeColumnsMode =
                DataGridViewAutoSizeColumnsMode.Fill;

            dgvDevoluciones.RowHeadersVisible = false;

            dgvDevoluciones.Columns.Add(
                "IdDetalle",
                "ID detalle");

            dgvDevoluciones.Columns.Add(
                "Libro",
                "Libro");

            dgvDevoluciones.Columns.Add(
                "Usuario",
                "Usuario");

            dgvDevoluciones.Columns.Add(
                "FechaPrestamo",
                "Fecha préstamo");

            dgvDevoluciones.Columns.Add(
                "FechaEsperada",
                "Devolución esperada");

            dgvDevoluciones.Columns.Add(
                "FechaDevolucion",
                "Fecha devolución");

            dgvDevoluciones.Columns.Add(
                "Estado",
                "Estado");

            Controls.Add(dgvDevoluciones);
        }

        private void CrearEtiqueta(
            string texto,
            int x,
            int y)
        {
            Label etiqueta = new Label();

            etiqueta.Text = texto;

            etiqueta.Font =
                new Font(
                    "Segoe UI",
                    10,
                    FontStyle.Bold);

            etiqueta.AutoSize = true;

            etiqueta.Location =
                new Point(x, y + 5);

            Controls.Add(etiqueta);
        }

        private Button CrearBoton(
            string texto,
            int x,
            int y,
            int ancho,
            int alto,
            EventHandler evento)
        {
            Button boton = new Button();

            boton.Text = texto;

            boton.Font =
                new Font(
                    "Segoe UI",
                    10,
                    FontStyle.Bold);

            boton.Size =
                new Size(ancho, alto);

            boton.Location =
                new Point(x, y);

            boton.BackColor =
                Color.FromArgb(31, 78, 121);

            boton.ForeColor =
                Color.White;

            boton.FlatStyle =
                FlatStyle.Flat;

            boton.FlatAppearance.BorderSize = 0;

            boton.Cursor =
                Cursors.Hand;

            boton.Click += evento;

            Controls.Add(boton);

            return boton;
        }

        // ==============================
        // CARGAR PRÉSTAMOS ACTIVOS
        // ==============================

        private void CargarPrestamosActivos()
        {
            try
            {
                List<Prestamo> prestamos =
                    negocio.Listar();

                List<Usuario> usuarios =
                    usuarioNegocio.Listar();

                List<Libro> libros =
                    libroNegocio.Listar();

                var lista =
                    new List<PrestamoSeleccion>();

                foreach (Prestamo prestamo in prestamos)
                {
                    if (!string.Equals(
                        prestamo.Estado,
                        "Activo",
                        StringComparison.OrdinalIgnoreCase))
                    {
                        continue;
                    }

                    List<DetallePrestamo> detallesPrestamo =
                        negocio.ListarDetalles(
                            prestamo.IdPrestamo);

                    Usuario? usuario =
                        usuarios.FirstOrDefault(
                            u => u.IdUsuario ==
                                 prestamo.IdUsuario);

                    foreach (DetallePrestamo detalle
                        in detallesPrestamo)
                    {
                        if (detalle.FechaDevolucion.HasValue)
                            continue;

                        Libro? libro =
                            libros.FirstOrDefault(
                                l => l.IdLibro ==
                                     detalle.IdLibro);

                        if (libro == null)
                            continue;

                        lista.Add(
                            new PrestamoSeleccion
                            {
                                IdPrestamo =
                                    prestamo.IdPrestamo,

                                IdDetalle =
                                    detalle.IdDetalle,

                                IdLibro =
                                    libro.IdLibro,

                                Descripcion =
                                    "Préstamo #"
                                    + prestamo.IdPrestamo
                                    + " - "
                                    + (usuario == null
                                        ? "Usuario desconocido"
                                        : usuario.Nombre
                                          + " "
                                          + usuario.Apellidos)
                                    + " - "
                                    + libro.Titulo
                                    + " - "
                                    + "Devolución: "
                                    + prestamo
                                        .FechaDevolucionEsperada
                                        .ToString("dd/MM/yyyy")
                            });
                    }
                }

                cboPrestamo.DataSource = null;
                cboPrestamo.DataSource = lista;

                cboPrestamo.DisplayMember =
                    "Descripcion";

                cboPrestamo.ValueMember =
                    "IdDetalle";

                if (lista.Count == 0)
                {
                    dgvDevoluciones.Rows.Clear();

                    MessageBox.Show(
                        "No hay libros pendientes de devolución.",
                        "Biblioteca",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "No se pudieron cargar las devoluciones.\n\n"
                    + ex.Message,
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        // ==============================
        // MOSTRAR DETALLE SELECCIONADO
        // ==============================

        private void SeleccionarPrestamo(
            object? sender,
            EventArgs e)
        {
            try
            {
                if (cboPrestamo.SelectedItem
                    is not PrestamoSeleccion seleccion)
                {
                    return;
                }

                List<Prestamo> prestamos =
                    negocio.Listar();

                List<Usuario> usuarios =
                    usuarioNegocio.Listar();

                List<Libro> libros =
                    libroNegocio.Listar();

                Prestamo? prestamo =
                    prestamos.FirstOrDefault(
                        p => p.IdPrestamo ==
                             seleccion.IdPrestamo);

                Usuario? usuario = null;

                Libro? libro =
                    libros.FirstOrDefault(
                        l => l.IdLibro ==
                             seleccion.IdLibro);

                if (prestamo != null)
                {
                    usuario =
                        usuarios.FirstOrDefault(
                            u => u.IdUsuario ==
                                 prestamo.IdUsuario);
                }

                dgvDevoluciones.Rows.Clear();

                int fila =
                    dgvDevoluciones.Rows.Add();

                dgvDevoluciones.Rows[fila]
                    .Cells["IdDetalle"].Value =
                    seleccion.IdDetalle;

                dgvDevoluciones.Rows[fila]
                    .Cells["Libro"].Value =
                    libro == null
                        ? "Libro desconocido"
                        : libro.Titulo;

                dgvDevoluciones.Rows[fila]
                    .Cells["Usuario"].Value =
                    usuario == null
                        ? "Usuario desconocido"
                        : usuario.Nombre
                          + " "
                          + usuario.Apellidos;

                if (prestamo != null)
                {
                    dgvDevoluciones.Rows[fila]
                        .Cells["FechaPrestamo"].Value =
                        prestamo.FechaPrestamo
                            .ToString("dd/MM/yyyy");

                    dgvDevoluciones.Rows[fila]
                        .Cells["FechaEsperada"].Value =
                        prestamo.FechaDevolucionEsperada
                            .ToString("dd/MM/yyyy");
                }

                dgvDevoluciones.Rows[fila]
                    .Cells["FechaDevolucion"].Value =
                    "Pendiente";

                dgvDevoluciones.Rows[fila]
                    .Cells["Estado"].Value =
                    "Pendiente";
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    ex.Message,
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        // ==============================
        // REGISTRAR DEVOLUCIÓN
        // ==============================

        private void RegistrarDevolucion(
            object? sender,
            EventArgs e)
        {
            try
            {
                if (cboPrestamo.SelectedItem
                    is not PrestamoSeleccion seleccion)
                {
                    MessageBox.Show(
                        "Seleccione un préstamo pendiente.",
                        "Biblioteca",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);

                    return;
                }

                DialogResult respuesta =
                    MessageBox.Show(
                        "¿Está seguro de registrar la devolución de este libro?",
                        "Confirmar devolución",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Question);

                if (respuesta != DialogResult.Yes)
                    return;

                negocio.RegistrarDevolucion(
                    seleccion.IdDetalle,
                    seleccion.IdLibro,
                    seleccion.IdPrestamo);

                MessageBox.Show(
                    "Devolución registrada correctamente.\n\n"
                    + "El ejemplar vuelve a estar disponible.",
                    "Biblioteca",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                CargarPrestamosActivos();

                CargarLibrosEnMemoria();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    ex.Message,
                    "No se pudo registrar la devolución",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
        }

        private void CargarLibrosEnMemoria()
        {
            // Actualiza la información disponible
            // al volver a cargar los préstamos.
            CargarPrestamosActivos();
        }

        // ==============================
        // ACTUALIZAR
        // ==============================

        private void ActualizarLista(
            object? sender,
            EventArgs e)
        {
            CargarPrestamosActivos();
        }

        // ==============================
        // CLASES AUXILIARES
        // ==============================

        private class PrestamoSeleccion
        {
            public int IdPrestamo { get; set; }

            public int IdDetalle { get; set; }

            public int IdLibro { get; set; }

            public string Descripcion { get; set; } = "";
        }

        private class DetalleDevolucion
        {
            public int IdDetalle { get; set; }

            public int IdLibro { get; set; }

            public string Libro { get; set; } = "";
        }
    }
}