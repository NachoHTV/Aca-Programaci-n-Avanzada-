﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Biblioteca.Entidades;
using Biblioteca.Negocio;

namespace Biblioteca.Presentacion
{
    public class FrmUsuarios : Form
    {
        private readonly UsuarioNegocio negocio;

        private int idUsuarioSeleccionado = 0;

        private DataGridView dgvUsuarios = null!;

        private TextBox txtDocumento = null!;
        private TextBox txtNombre = null!;
        private TextBox txtApellidos = null!;
        private TextBox txtTelefono = null!;
        private TextBox txtCorreo = null!;
        private TextBox txtPrograma = null!;

        private Button btnNuevo = null!;
        private Button btnGuardar = null!;
        private Button btnEditar = null!;
        private Button btnEliminar = null!;
        private Button btnActualizar = null!;

        public FrmUsuarios()
        {
            negocio = new UsuarioNegocio();

            ConfigurarFormulario();
            CrearInterfaz();
            CargarUsuarios();
        }

        private void ConfigurarFormulario()
        {
            Text = "Gestión de Usuarios";
            StartPosition = FormStartPosition.CenterScreen;
            Size = new Size(1150, 750);
            MinimumSize = new Size(1050, 650);
            BackColor = Color.White;
        }

        private void CrearInterfaz()
        {
            Label titulo = new Label();

            titulo.Text = "GESTIÓN DE USUARIOS";
            titulo.Font = new Font(
                "Segoe UI",
                24,
                FontStyle.Bold);

            titulo.ForeColor =
                Color.FromArgb(31, 78, 121);

            titulo.AutoSize = true;
            titulo.Location =
                new Point(420, 25);

            Controls.Add(titulo);

            // ==============================
            // CAMPOS
            // ==============================

            CrearEtiqueta("Documento:", 50, 100);
            txtDocumento = CrearTextBox(
                170,
                95,
                250);

            CrearEtiqueta("Nombre:", 50, 150);
            txtNombre = CrearTextBox(
                170,
                145,
                250);

            CrearEtiqueta("Apellidos:", 50, 200);
            txtApellidos = CrearTextBox(
                170,
                195,
                250);

            CrearEtiqueta("Teléfono:", 50, 250);
            txtTelefono = CrearTextBox(
                170,
                245,
                250);

            CrearEtiqueta("Correo:", 500, 100);
            txtCorreo = CrearTextBox(
                620,
                95,
                250);

            CrearEtiqueta("Programa:", 500, 150);
            txtPrograma = CrearTextBox(
                620,
                145,
                250);

            // ==============================
            // BOTONES
            // ==============================

            btnNuevo = CrearBoton(
                "Nuevo",
                900,
                95,
                110,
                40,
                NuevoUsuario);

            btnGuardar = CrearBoton(
                "Guardar",
                1020,
                95,
                110,
                40,
                GuardarUsuario);

            btnEditar = CrearBoton(
                "Editar",
                900,
                150,
                110,
                40,
                EditarUsuario);

            btnEliminar = CrearBoton(
                "Eliminar",
                1020,
                150,
                110,
                40,
                EliminarUsuario);

            btnActualizar = CrearBoton(
                "Actualizar",
                620,
                200,
                250,
                40,
                ActualizarLista);

            // ==============================
            // TABLA
            // ==============================

            dgvUsuarios = new DataGridView();

            dgvUsuarios.Location =
                new Point(50, 330);

            dgvUsuarios.Size =
                new Size(1080, 300);

            dgvUsuarios.ReadOnly = true;

            dgvUsuarios.AllowUserToAddRows = false;
            dgvUsuarios.AllowUserToDeleteRows = false;

            dgvUsuarios.SelectionMode =
                DataGridViewSelectionMode.FullRowSelect;

            dgvUsuarios.MultiSelect = false;

            dgvUsuarios.AutoSizeColumnsMode =
                DataGridViewAutoSizeColumnsMode.Fill;

            dgvUsuarios.RowHeadersVisible = false;

            dgvUsuarios.Columns.Add(
                "IdUsuario",
                "ID");

            dgvUsuarios.Columns.Add(
                "Documento",
                "Documento");

            dgvUsuarios.Columns.Add(
                "Nombre",
                "Nombre");

            dgvUsuarios.Columns.Add(
                "Apellidos",
                "Apellidos");

            dgvUsuarios.Columns.Add(
                "Telefono",
                "Teléfono");

            dgvUsuarios.Columns.Add(
                "Correo",
                "Correo");

            dgvUsuarios.Columns.Add(
                "ProgramaAcademico",
                "Programa académico");

            dgvUsuarios.CellClick +=
                SeleccionarUsuario;

            Controls.Add(dgvUsuarios);
        }

        // ==============================
        // CONTROLES
        // ==============================

        private void CrearEtiqueta(
            string texto,
            int x,
            int y)
        {
            Label etiqueta = new Label();

            etiqueta.Text = texto;

            etiqueta.Font = new Font(
                "Segoe UI",
                10,
                FontStyle.Bold);

            etiqueta.AutoSize = true;

            etiqueta.Location =
                new Point(x, y + 5);

            Controls.Add(etiqueta);
        }

        private TextBox CrearTextBox(
            int x,
            int y,
            int ancho)
        {
            TextBox texto = new TextBox();

            texto.Size =
                new Size(ancho, 30);

            texto.Location =
                new Point(x, y);

            texto.Font =
                new Font("Segoe UI", 10);

            Controls.Add(texto);

            return texto;
        }

        private Button CrearBoton(
            string texto,
            int x,
            int y,
            int ancho,
            int alto,
            EventHandler evento)
        {
            Button boton = new Button();

            boton.Text = texto;

            boton.Font =
                new Font(
                    "Segoe UI",
                    10,
                    FontStyle.Bold);

            boton.Size =
                new Size(ancho, alto);

            boton.Location =
                new Point(x, y);

            boton.BackColor =
                Color.FromArgb(31, 78, 121);

            boton.ForeColor =
                Color.White;

            boton.FlatStyle =
                FlatStyle.Flat;

            boton.FlatAppearance.BorderSize = 0;

            boton.Cursor =
                Cursors.Hand;

            boton.Click += evento;

            Controls.Add(boton);

            return boton;
        }

        // ==============================
        // CARGAR USUARIOS
        // ==============================

        private void CargarUsuarios()
        {
            try
            {
                var usuarios =
                    negocio.Listar();

                dgvUsuarios.Rows.Clear();

                foreach (Usuario usuario in usuarios)
                {
                    int fila =
                        dgvUsuarios.Rows.Add();

                    dgvUsuarios.Rows[fila]
                        .Cells["IdUsuario"].Value =
                        usuario.IdUsuario;

                    dgvUsuarios.Rows[fila]
                        .Cells["Documento"].Value =
                        usuario.Documento;

                    dgvUsuarios.Rows[fila]
                        .Cells["Nombre"].Value =
                        usuario.Nombre;

                    dgvUsuarios.Rows[fila]
                        .Cells["Apellidos"].Value =
                        usuario.Apellidos;

                    dgvUsuarios.Rows[fila]
                        .Cells["Telefono"].Value =
                        usuario.Telefono;

                    dgvUsuarios.Rows[fila]
                        .Cells["Correo"].Value =
                        usuario.Correo;

                    dgvUsuarios.Rows[fila]
                        .Cells["ProgramaAcademico"].Value =
                        usuario.ProgramaAcademico;

                    dgvUsuarios.Rows[fila].Tag =
                        usuario;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "No se pudieron cargar los usuarios.\n\n"
                    + ex.Message,
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        // ==============================
        // SELECCIONAR USUARIO
        // ==============================

        private void SeleccionarUsuario(
            object? sender,
            DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
                return;

            DataGridViewRow fila =
                dgvUsuarios.Rows[e.RowIndex];

            if (fila.Tag is Usuario usuario)
            {
                idUsuarioSeleccionado =
                    usuario.IdUsuario;

                txtDocumento.Text =
                    usuario.Documento;

                txtNombre.Text =
                    usuario.Nombre;

                txtApellidos.Text =
                    usuario.Apellidos;

                txtTelefono.Text =
                    usuario.Telefono;

                txtCorreo.Text =
                    usuario.Correo;

                txtPrograma.Text =
                    usuario.ProgramaAcademico;
            }
        }

        // ==============================
        // NUEVO
        // ==============================

        private void NuevoUsuario(
            object? sender,
            EventArgs e)
        {
            LimpiarFormulario();
        }

        // ==============================
        // GUARDAR
        // ==============================

        private void GuardarUsuario(
            object? sender,
            EventArgs e)
        {
            try
            {
                Usuario usuario = new Usuario
                {
                    Documento =
                        txtDocumento.Text.Trim(),

                    Nombre =
                        txtNombre.Text.Trim(),

                    Apellidos =
                        txtApellidos.Text.Trim(),

                    Telefono =
                        txtTelefono.Text.Trim(),

                    Correo =
                        txtCorreo.Text.Trim(),

                    ProgramaAcademico =
                        txtPrograma.Text.Trim()
                };

                negocio.Registrar(usuario);

                MessageBox.Show(
                    "Usuario registrado correctamente.",
                    "Biblioteca",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                LimpiarFormulario();

                CargarUsuarios();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    ex.Message,
                    "No se pudo registrar el usuario",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
        }

        // ==============================
        // EDITAR
        // ==============================

        private void EditarUsuario(
            object? sender,
            EventArgs e)
        {
            try
            {
                if (idUsuarioSeleccionado <= 0)
                {
                    MessageBox.Show(
                        "Seleccione un usuario de la tabla.",
                        "Biblioteca",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);

                    return;
                }

                Usuario usuario = new Usuario
                {
                    IdUsuario =
                        idUsuarioSeleccionado,

                    Documento =
                        txtDocumento.Text.Trim(),

                    Nombre =
                        txtNombre.Text.Trim(),

                    Apellidos =
                        txtApellidos.Text.Trim(),

                    Telefono =
                        txtTelefono.Text.Trim(),

                    Correo =
                        txtCorreo.Text.Trim(),

                    ProgramaAcademico =
                        txtPrograma.Text.Trim()
                };

                negocio.Actualizar(usuario);

                MessageBox.Show(
                    "Usuario actualizado correctamente.",
                    "Biblioteca",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                LimpiarFormulario();

                CargarUsuarios();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    ex.Message,
                    "No se pudo actualizar el usuario",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
        }

        // ==============================
        // ELIMINAR
        // ==============================

        private void EliminarUsuario(
            object? sender,
            EventArgs e)
        {
            try
            {
                if (idUsuarioSeleccionado <= 0)
                {
                    MessageBox.Show(
                        "Seleccione un usuario de la tabla.",
                        "Biblioteca",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);

                    return;
                }

                DialogResult respuesta =
                    MessageBox.Show(
                        "¿Está seguro de eliminar el usuario seleccionado?",
                        "Confirmar eliminación",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Question);

                if (respuesta !=
                    DialogResult.Yes)
                {
                    return;
                }

                negocio.Eliminar(
                    idUsuarioSeleccionado);

                MessageBox.Show(
                    "Usuario eliminado correctamente.",
                    "Biblioteca",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                LimpiarFormulario();

                CargarUsuarios();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    ex.Message,
                    "No se pudo eliminar el usuario",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
        }

        // ==============================
        // ACTUALIZAR
        // ==============================

        private void ActualizarLista(
            object? sender,
            EventArgs e)
        {
            CargarUsuarios();
        }

        // ==============================
        // LIMPIAR
        // ==============================

        private void LimpiarFormulario()
        {
            idUsuarioSeleccionado = 0;

            txtDocumento.Clear();
            txtNombre.Clear();
            txtApellidos.Clear();
            txtTelefono.Clear();
            txtCorreo.Clear();
            txtPrograma.Clear();

            dgvUsuarios.ClearSelection();

            txtDocumento.Focus();
        }
    }
}