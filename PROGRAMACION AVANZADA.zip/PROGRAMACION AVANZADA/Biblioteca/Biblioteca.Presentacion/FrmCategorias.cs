﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Biblioteca.Entidades;
using Biblioteca.Negocio;

namespace Biblioteca.Presentacion
{
    public class FrmCategorias : Form
    {
        // =========================
        // VARIABLES
        // =========================

        private readonly CategoriaNegocio negocio;

        private int idCategoriaSeleccionada = 0;

        // =========================
        // CONTROLES
        // =========================

        private DataGridView dgvCategorias = null!;

        private TextBox txtNombre = null!;

        private Button btnNuevo = null!;
        private Button btnGuardar = null!;
        private Button btnEditar = null!;
        private Button btnEliminar = null!;
        private Button btnActualizar = null!;


        // =========================
        // CONSTRUCTOR
        // =========================

        public FrmCategorias()
        {
            negocio = new CategoriaNegocio();

            ConfigurarFormulario();

            CrearInterfaz();

            CargarCategorias();
        }


        // =========================
        // CONFIGURAR FORMULARIO
        // =========================

        private void ConfigurarFormulario()
        {
            Text = "Gestión de Categorías";

            StartPosition =
                FormStartPosition.CenterScreen;

            Size =
                new Size(900, 600);

            MinimumSize =
                new Size(800, 500);

            BackColor =
                Color.White;
        }


        // =========================
        // CREAR INTERFAZ
        // =========================

        private void CrearInterfaz()
        {
            // =========================
            // TÍTULO
            // =========================

            Label titulo =
                new Label();

            titulo.Text =
                "GESTIÓN DE CATEGORÍAS";

            titulo.Font =
                new Font(
                    "Segoe UI",
                    24,
                    FontStyle.Bold);

            titulo.ForeColor =
                Color.FromArgb(
                    31,
                    78,
                    121);

            titulo.AutoSize =
                true;

            titulo.Location =
                new Point(280, 30);

            Controls.Add(titulo);


            // =========================
            // NOMBRE
            // =========================

            CrearEtiqueta(
                "Nombre:",
                70,
                110);

            txtNombre =
                CrearTextBox(
                    160,
                    105,
                    300);


            // =========================
            // BOTÓN NUEVO
            // =========================

            btnNuevo =
                CrearBoton(
                    "Nuevo",
                    500,
                    105,
                    110,
                    NuevoCategoria);


            // =========================
            // BOTÓN GUARDAR
            // =========================

            btnGuardar =
                CrearBoton(
                    "Guardar",
                    620,
                    105,
                    110,
                    GuardarCategoria);


            // =========================
            // BOTÓN EDITAR
            // =========================

            btnEditar =
                CrearBoton(
                    "Editar",
                    500,
                    155,
                    110,
                    EditarCategoria);


            // =========================
            // BOTÓN ELIMINAR
            // =========================

            btnEliminar =
                CrearBoton(
                    "Eliminar",
                    620,
                    155,
                    110,
                    EliminarCategoria);


            // =========================
            // BOTÓN ACTUALIZAR
            // =========================

            btnActualizar =
                CrearBoton(
                    "Actualizar",
                    160,
                    155,
                    300,
                    ActualizarLista);


            // =========================
            // TABLA
            // =========================

            dgvCategorias =
                new DataGridView();

            dgvCategorias.Location =
                new Point(70, 240);

            dgvCategorias.Size =
                new Size(660, 250);

            dgvCategorias.AutoGenerateColumns =
                true;

            dgvCategorias.ReadOnly =
                true;

            dgvCategorias.AllowUserToAddRows =
                false;

            dgvCategorias.AllowUserToDeleteRows =
                false;

            dgvCategorias.SelectionMode =
                DataGridViewSelectionMode.FullRowSelect;

            dgvCategorias.MultiSelect =
                false;

            dgvCategorias.AutoSizeColumnsMode =
                DataGridViewAutoSizeColumnsMode.Fill;

            dgvCategorias.CellClick +=
                SeleccionarCategoria;

            Controls.Add(
                dgvCategorias);
        }


        // =========================
        // CREAR ETIQUETA
        // =========================

        private void CrearEtiqueta(
            string texto,
            int x,
            int y)
        {
            Label etiqueta =
                new Label();

            etiqueta.Text =
                texto;

            etiqueta.Font =
                new Font(
                    "Segoe UI",
                    10,
                    FontStyle.Bold);

            etiqueta.AutoSize =
                true;

            etiqueta.Location =
                new Point(
                    x,
                    y + 5);

            Controls.Add(
                etiqueta);
        }


        // =========================
        // CREAR TEXTBOX
        // =========================

        private TextBox CrearTextBox(
            int x,
            int y,
            int ancho)
        {
            TextBox texto =
                new TextBox();

            texto.Size =
                new Size(
                    ancho,
                    30);

            texto.Location =
                new Point(
                    x,
                    y);

            texto.Font =
                new Font(
                    "Segoe UI",
                    10);

            Controls.Add(
                texto);

            return texto;
        }


        // =========================
        // CREAR BOTÓN
        // =========================

        private Button CrearBoton(
            string texto,
            int x,
            int y,
            int ancho,
            EventHandler evento)
        {
            Button boton =
                new Button();

            boton.Text =
                texto;

            boton.Font =
                new Font(
                    "Segoe UI",
                    10,
                    FontStyle.Bold);

            boton.Size =
                new Size(
                    ancho,
                    40);

            boton.Location =
                new Point(
                    x,
                    y);

            boton.BackColor =
                Color.FromArgb(
                    31,
                    78,
                    121);

            boton.ForeColor =
                Color.White;

            boton.FlatStyle =
                FlatStyle.Flat;

            boton.FlatAppearance.BorderSize =
                0;

            boton.Cursor =
                Cursors.Hand;

            boton.Click +=
                evento;

            Controls.Add(
                boton);

            return boton;
        }


        // =========================
        // CARGAR CATEGORÍAS
        // =========================

        private void CargarCategorias()
        {
            try
            {
                dgvCategorias.DataSource =
                    null;

                dgvCategorias.DataSource =
                    negocio.Listar();

                if (dgvCategorias.Columns["IdCategoria"] != null)
                {
                    dgvCategorias.Columns["IdCategoria"]
                        .HeaderText = "ID";
                }

                if (dgvCategorias.Columns["Nombre"] != null)
                {
                    dgvCategorias.Columns["Nombre"]
                        .HeaderText = "Nombre";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "No se pudieron cargar las categorías.\n\n" +
                    ex.Message,
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }


        // =========================
        // SELECCIONAR CATEGORÍA
        // =========================

        private void SeleccionarCategoria(
            object? sender,
            DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
            {
                return;
            }

            DataGridViewRow fila =
                dgvCategorias.Rows[e.RowIndex];

            if (fila.DataBoundItem is Categoria categoria)
            {
                idCategoriaSeleccionada =
                    categoria.IdCategoria;

                txtNombre.Text =
                    categoria.Nombre;
            }
        }


        // =========================
        // NUEVA CATEGORÍA
        // =========================

        private void NuevoCategoria(
            object? sender,
            EventArgs e)
        {
            LimpiarFormulario();
        }


        // =========================
        // GUARDAR CATEGORÍA
        // =========================

        private void GuardarCategoria(
            object? sender,
            EventArgs e)
        {
            try
            {
                Categoria categoria =
                    new Categoria();

                categoria.Nombre =
                    txtNombre.Text.Trim();

                negocio.Registrar(
                    categoria);

                MessageBox.Show(
                    "Categoría registrada correctamente.",
                    "Biblioteca",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                LimpiarFormulario();

                CargarCategorias();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    ex.Message,
                    "No se pudo registrar la categoría",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
        }


        // =========================
        // EDITAR CATEGORÍA
        // =========================

        private void EditarCategoria(
            object? sender,
            EventArgs e)
        {
            try
            {
                if (idCategoriaSeleccionada <= 0)
                {
                    MessageBox.Show(
                        "Seleccione una categoría de la tabla.",
                        "Biblioteca",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);

                    return;
                }

                Categoria categoria =
                    new Categoria();

                categoria.IdCategoria =
                    idCategoriaSeleccionada;

                categoria.Nombre =
                    txtNombre.Text.Trim();

                negocio.Actualizar(
                    categoria);

                MessageBox.Show(
                    "Categoría actualizada correctamente.",
                    "Biblioteca",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                LimpiarFormulario();

                CargarCategorias();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    ex.Message,
                    "No se pudo actualizar la categoría",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
        }


        // =========================
        // ELIMINAR CATEGORÍA
        // =========================

        private void EliminarCategoria(
            object? sender,
            EventArgs e)
        {
            try
            {
                if (idCategoriaSeleccionada <= 0)
                {
                    MessageBox.Show(
                        "Seleccione una categoría de la tabla.",
                        "Biblioteca",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);

                    return;
                }

                DialogResult respuesta =
                    MessageBox.Show(
                        "¿Está seguro de eliminar " +
                        "la categoría seleccionada?",
                        "Confirmar eliminación",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Question);

                if (respuesta !=
                    DialogResult.Yes)
                {
                    return;
                }

                negocio.Eliminar(
                    idCategoriaSeleccionada);

                MessageBox.Show(
                    "Categoría eliminada correctamente.",
                    "Biblioteca",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                LimpiarFormulario();

                CargarCategorias();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    ex.Message,
                    "No se pudo eliminar la categoría",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
        }


        // =========================
        // ACTUALIZAR LISTA
        // =========================

        private void ActualizarLista(
            object? sender,
            EventArgs e)
        {
            CargarCategorias();
        }


        // =========================
        // LIMPIAR FORMULARIO
        // =========================

        private void LimpiarFormulario()
        {
            idCategoriaSeleccionada = 0;

            txtNombre.Clear();

            dgvCategorias.ClearSelection();

            txtNombre.Focus();
        }
    }
}