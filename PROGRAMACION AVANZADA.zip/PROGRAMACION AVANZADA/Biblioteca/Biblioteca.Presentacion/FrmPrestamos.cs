﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Biblioteca.Entidades;
using Biblioteca.Negocio;

namespace Biblioteca.Presentacion
{
    public class FrmPrestamos : Form
    {
        private readonly PrestamoNegocio negocio;
        private readonly UsuarioNegocio usuarioNegocio;
        private readonly LibroNegocio libroNegocio;

        private ComboBox cboUsuario = null!;
        private CheckedListBox clbLibros = null!;
        private DateTimePicker dtpFechaDevolucion = null!;
        private DataGridView dgvPrestamos = null!;

        private Button btnNuevo = null!;
        private Button btnGuardar = null!;
        private Button btnActualizar = null!;

        public FrmPrestamos()
        {
            negocio = new PrestamoNegocio();
            usuarioNegocio = new UsuarioNegocio();
            libroNegocio = new LibroNegocio();

            ConfigurarFormulario();
            CrearInterfaz();
            CargarUsuarios();
            CargarLibros();
            CargarPrestamos();
        }

        private void ConfigurarFormulario()
        {
            Text = "Gestión de Préstamos";
            StartPosition = FormStartPosition.CenterScreen;
            Size = new Size(1150, 750);
            MinimumSize = new Size(1050, 650);
            BackColor = Color.White;
        }

        private void CrearInterfaz()
        {
            Label titulo = new Label();

            titulo.Text = "GESTIÓN DE PRÉSTAMOS";
            titulo.Font = new Font(
                "Segoe UI",
                24,
                FontStyle.Bold);

            titulo.ForeColor =
                Color.FromArgb(31, 78, 121);

            titulo.AutoSize = true;
            titulo.Location =
                new Point(390, 25);

            Controls.Add(titulo);

            CrearEtiqueta(
                "Usuario:",
                50,
                100);

            cboUsuario = new ComboBox();

            cboUsuario.Location =
                new Point(160, 95);

            cboUsuario.Size =
                new Size(350, 30);

            cboUsuario.Font =
                new Font("Segoe UI", 10);

            cboUsuario.DropDownStyle =
                ComboBoxStyle.DropDownList;

            Controls.Add(cboUsuario);

            CrearEtiqueta(
                "Devolución:",
                50,
                150);

            dtpFechaDevolucion =
                new DateTimePicker();

            dtpFechaDevolucion.Format =
                DateTimePickerFormat.Short;

            dtpFechaDevolucion.Location =
                new Point(160, 145);

            dtpFechaDevolucion.Size =
                new Size(200, 30);

            dtpFechaDevolucion.Font =
                new Font("Segoe UI", 10);

            dtpFechaDevolucion.Value =
                DateTime.Today.AddDays(7);

            dtpFechaDevolucion.MinDate =
                DateTime.Today;

            Controls.Add(dtpFechaDevolucion);

            CrearEtiqueta(
                "Seleccione libros:",
                50,
                210);

            clbLibros =
                new CheckedListBox();

            clbLibros.Location =
                new Point(160, 205);

            clbLibros.Size =
                new Size(500, 150);

            clbLibros.Font =
                new Font("Segoe UI", 10);

            clbLibros.CheckOnClick = true;
            clbLibros.HorizontalScrollbar = true;

            Controls.Add(clbLibros);

            btnNuevo = CrearBoton(
                "Nuevo",
                720,
                95,
                150,
                45,
                NuevoPrestamo);

            btnGuardar = CrearBoton(
                "Registrar préstamo",
                720,
                155,
                300,
                45,
                GuardarPrestamo);

            btnActualizar = CrearBoton(
                "Actualizar",
                720,
                215,
                300,
                45,
                ActualizarLista);

            Label informacion = new Label();

            informacion.Text =
                "Seleccione uno o varios libros disponibles.";

            informacion.Font =
                new Font(
                    "Segoe UI",
                    9,
                    FontStyle.Italic);

            informacion.ForeColor = Color.Gray;
            informacion.AutoSize = true;

            informacion.Location =
                new Point(160, 365);

            Controls.Add(informacion);

            dgvPrestamos =
                new DataGridView();

            dgvPrestamos.Location =
                new Point(50, 410);

            dgvPrestamos.Size =
                new Size(1020, 230);

            dgvPrestamos.ReadOnly = true;

            dgvPrestamos.AllowUserToAddRows = false;
            dgvPrestamos.AllowUserToDeleteRows = false;

            dgvPrestamos.SelectionMode =
                DataGridViewSelectionMode.FullRowSelect;

            dgvPrestamos.MultiSelect = false;

            dgvPrestamos.AutoSizeColumnsMode =
                DataGridViewAutoSizeColumnsMode.Fill;

            dgvPrestamos.RowHeadersVisible = false;

            dgvPrestamos.Columns.Add(
                "IdPrestamo",
                "ID");

            dgvPrestamos.Columns.Add(
                "Usuario",
                "Usuario");

            dgvPrestamos.Columns.Add(
                "FechaPrestamo",
                "Fecha préstamo");

            dgvPrestamos.Columns.Add(
                "FechaDevolucionEsperada",
                "Devolución esperada");

            dgvPrestamos.Columns.Add(
                "Estado",
                "Estado");

            Controls.Add(dgvPrestamos);
        }

        private void CrearEtiqueta(
            string texto,
            int x,
            int y)
        {
            Label etiqueta = new Label();

            etiqueta.Text = texto;

            etiqueta.Font =
                new Font(
                    "Segoe UI",
                    10,
                    FontStyle.Bold);

            etiqueta.AutoSize = true;

            etiqueta.Location =
                new Point(x, y + 5);

            Controls.Add(etiqueta);
        }

        private Button CrearBoton(
            string texto,
            int x,
            int y,
            int ancho,
            int alto,
            EventHandler evento)
        {
            Button boton = new Button();

            boton.Text = texto;

            boton.Font =
                new Font(
                    "Segoe UI",
                    10,
                    FontStyle.Bold);

            boton.Size =
                new Size(ancho, alto);

            boton.Location =
                new Point(x, y);

            boton.BackColor =
                Color.FromArgb(31, 78, 121);

            boton.ForeColor = Color.White;

            boton.FlatStyle =
                FlatStyle.Flat;

            boton.FlatAppearance.BorderSize = 0;

            boton.Cursor =
                Cursors.Hand;

            boton.Click += evento;

            Controls.Add(boton);

            return boton;
        }

        private void CargarUsuarios()
        {
            try
            {
                List<Usuario> usuarios =
                    usuarioNegocio.Listar();

                var listaUsuarios =
                    usuarios.Select(u => new
                    {
                        IdUsuario = u.IdUsuario,
                        NombreCompleto =
                            u.Nombre + " " +
                            u.Apellidos +
                            " - " +
                            u.Documento
                    }).ToList();

                cboUsuario.DataSource = null;
                cboUsuario.DataSource = listaUsuarios;

                cboUsuario.DisplayMember =
                    "NombreCompleto";

                cboUsuario.ValueMember =
                    "IdUsuario";
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "No se pudieron cargar los usuarios.\n\n"
                    + ex.Message,
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void CargarLibros()
        {
            try
            {
                List<Libro> libros =
                    libroNegocio.Listar();

                clbLibros.Items.Clear();

                foreach (Libro libro in libros)
                {
                    if (libro.Disponible > 0)
                    {
                        clbLibros.Items.Add(
                            libro,
                            false);
                    }
                }

                clbLibros.DisplayMember =
                    "Titulo";

                clbLibros.Format -=
                    MostrarLibroDisponible;

                clbLibros.Format +=
                    MostrarLibroDisponible;
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "No se pudieron cargar los libros.\n\n"
                    + ex.Message,
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void MostrarLibroDisponible(
            object? sender,
            ListControlConvertEventArgs e)
        {
            if (e.ListItem is Libro libro)
            {
                e.Value =
                    libro.Titulo +
                    " - Disponible: " +
                    libro.Disponible;
            }
        }

        private void CargarPrestamos()
        {
            try
            {
                List<Prestamo> prestamos =
                    negocio.Listar();

                List<Usuario> usuarios =
                    usuarioNegocio.Listar();

                dgvPrestamos.Rows.Clear();

                foreach (Prestamo prestamo in prestamos)
                {
                    Usuario? usuario =
                        usuarios.FirstOrDefault(
                            u => u.IdUsuario ==
                                 prestamo.IdUsuario);

                    int fila =
                        dgvPrestamos.Rows.Add();

                    dgvPrestamos.Rows[fila]
                        .Cells["IdPrestamo"].Value =
                        prestamo.IdPrestamo;

                    dgvPrestamos.Rows[fila]
                        .Cells["Usuario"].Value =
                        usuario == null
                            ? "Usuario desconocido"
                            : usuario.Nombre + " " +
                              usuario.Apellidos;

                    dgvPrestamos.Rows[fila]
                        .Cells["FechaPrestamo"].Value =
                        prestamo.FechaPrestamo
                            .ToString("dd/MM/yyyy");

                    dgvPrestamos.Rows[fila]
                        .Cells[
                            "FechaDevolucionEsperada"]
                        .Value =
                        prestamo.FechaDevolucionEsperada
                            .ToString("dd/MM/yyyy");

                    dgvPrestamos.Rows[fila]
                        .Cells["Estado"].Value =
                        prestamo.Estado;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "No se pudieron cargar los préstamos.\n\n"
                    + ex.Message,
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void NuevoPrestamo(
            object? sender,
            EventArgs e)
        {
            LimpiarFormulario();
        }

        private void GuardarPrestamo(
            object? sender,
            EventArgs e)
        {
            try
            {
                if (cboUsuario.SelectedValue == null)
                {
                    MessageBox.Show(
                        "Debe seleccionar un usuario.",
                        "Biblioteca",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);

                    return;
                }

                List<int> librosSeleccionados =
                    new List<int>();

                foreach (object item
                    in clbLibros.CheckedItems)
                {
                    if (item is Libro libro)
                    {
                        librosSeleccionados.Add(
                            libro.IdLibro);
                    }
                }

                if (librosSeleccionados.Count == 0)
                {
                    MessageBox.Show(
                        "Debe seleccionar al menos un libro.",
                        "Biblioteca",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);

                    return;
                }

                int idUsuario =
                    Convert.ToInt32(
                        cboUsuario.SelectedValue);

                int idPrestamo =
                    negocio.RegistrarPrestamo(
                        idUsuario,
                        librosSeleccionados,
                        dtpFechaDevolucion.Value);

                MessageBox.Show(
                    "Préstamo registrado correctamente.\n\n"
                    + "Número de préstamo: "
                    + idPrestamo,
                    "Biblioteca",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                LimpiarFormulario();

                CargarLibros();
                CargarPrestamos();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    ex.Message,
                    "No se pudo registrar el préstamo",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
        }

        private void ActualizarLista(
            object? sender,
            EventArgs e)
        {
            CargarUsuarios();
            CargarLibros();
            CargarPrestamos();
        }

        private void LimpiarFormulario()
        {
            if (cboUsuario.Items.Count > 0)
            {
                cboUsuario.SelectedIndex = 0;
            }

            dtpFechaDevolucion.Value =
                DateTime.Today.AddDays(7);

            for (int i = 0;
                 i < clbLibros.Items.Count;
                 i++)
            {
                clbLibros.SetItemChecked(
                    i,
                    false);
            }
        }
    }
}