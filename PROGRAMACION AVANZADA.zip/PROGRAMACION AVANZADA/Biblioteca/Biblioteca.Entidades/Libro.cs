﻿namespace Biblioteca.Entidades
{
    public class Libro
    {
        public int IdLibro { get; set; }

        public string Codigo { get; set; } = string.Empty;

        public string ISBN { get; set; } = string.Empty;

        public string Titulo { get; set; } = string.Empty;

        public int IdAutor { get; set; }

        public int IdCategoria { get; set; }

        public int Cantidad { get; set; }

        public int Disponible { get; set; }

        public Autor? Autor { get; set; }

        public Categoria? Categoria { get; set; }
    }
}