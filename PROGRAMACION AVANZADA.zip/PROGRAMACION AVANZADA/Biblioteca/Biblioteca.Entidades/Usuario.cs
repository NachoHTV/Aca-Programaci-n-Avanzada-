﻿namespace Biblioteca.Entidades
{
    public class Usuario
    {
        public int IdUsuario { get; set; }

        public string Documento { get; set; } = string.Empty;

        public string Nombre { get; set; } = string.Empty;

        public string Apellidos { get; set; } = string.Empty;

        public string Telefono { get; set; } = string.Empty;

        public string Correo { get; set; } = string.Empty;

        public string ProgramaAcademico { get; set; } = string.Empty;
    }
}