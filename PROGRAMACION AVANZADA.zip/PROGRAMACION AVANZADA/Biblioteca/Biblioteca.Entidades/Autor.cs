﻿namespace Biblioteca.Entidades
{
    public class Autor
    {
        public int IdAutor { get; set; }

        public string Codigo { get; set; } = string.Empty;

        public string Nombre { get; set; } = string.Empty;

        public string Apellidos { get; set; } = string.Empty;

        public string Nacionalidad { get; set; } = string.Empty;

        public DateTime FechaNacimiento { get; set; }
    }
}