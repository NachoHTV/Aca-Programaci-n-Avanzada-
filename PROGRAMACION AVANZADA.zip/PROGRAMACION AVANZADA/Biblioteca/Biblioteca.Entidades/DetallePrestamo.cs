﻿namespace Biblioteca.Entidades
{
    public class DetallePrestamo
    {
        public int IdDetalle { get; set; }

        public int IdPrestamo { get; set; }

        public int IdLibro { get; set; }

        public DateTime? FechaDevolucion { get; set; }

        public Prestamo? Prestamo { get; set; }

        public Libro? Libro { get; set; }
    }
}