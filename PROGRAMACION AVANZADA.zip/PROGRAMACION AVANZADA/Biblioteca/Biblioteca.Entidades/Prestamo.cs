﻿namespace Biblioteca.Entidades
{
    public class Prestamo
    {
        public int IdPrestamo { get; set; }

        public int IdUsuario { get; set; }

        public DateTime FechaPrestamo { get; set; }

        public DateTime FechaDevolucionEsperada { get; set; }

        public string Estado { get; set; } = "Activo";

        public Usuario? Usuario { get; set; }

        public List<DetallePrestamo> Detalles { get; set; } = new List<DetallePrestamo>();
    }
}