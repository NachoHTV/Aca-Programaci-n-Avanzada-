﻿using System;
using System.Linq;
using Biblioteca.Datos;
using Biblioteca.Entidades;

namespace Biblioteca.Negocio
{
    public class LibroNegocio
    {
        private readonly LibroDatos datos =
            new LibroDatos();

        public List<Libro> Listar()
        {
            return datos.Listar();
        }

        public void Registrar(Libro libro)
        {
            Validar(libro);

            ValidarCodigoUnico(
                libro.Codigo,
                0);

            ValidarISBNUnico(
                libro.ISBN,
                0);

            if (libro.Cantidad <= 0)
            {
                throw new Exception(
                    "La cantidad debe ser mayor que cero.");
            }

            libro.Disponible =
                libro.Cantidad;

            datos.Insertar(libro);
        }

        public void Actualizar(Libro libro)
        {
            if (libro.IdLibro <= 0)
            {
                throw new Exception(
                    "El libro seleccionado no es válido.");
            }

            Validar(libro);

            ValidarCodigoUnico(
                libro.Codigo,
                libro.IdLibro);

            ValidarISBNUnico(
                libro.ISBN,
                libro.IdLibro);

            if (libro.Cantidad < 0)
            {
                throw new Exception(
                    "La cantidad no puede ser negativa.");
            }

            if (libro.Disponible < 0)
            {
                throw new Exception(
                    "La disponibilidad no puede ser negativa.");
            }

            if (libro.Disponible >
                libro.Cantidad)
            {
                throw new Exception(
                    "La cantidad disponible no puede ser mayor que la cantidad total.");
            }

            datos.Actualizar(libro);
        }

        public void Eliminar(int idLibro)
        {
            if (idLibro <= 0)
            {
                throw new Exception(
                    "Debe seleccionar un libro válido.");
            }

            datos.Eliminar(idLibro);
        }

        private void Validar(Libro libro)
        {
            if (string.IsNullOrWhiteSpace(
                libro.Codigo))
            {
                throw new Exception(
                    "El código del libro es obligatorio.");
            }

            if (string.IsNullOrWhiteSpace(
                libro.ISBN))
            {
                throw new Exception(
                    "El ISBN del libro es obligatorio.");
            }

            if (!libro.ISBN.All(char.IsDigit))
            {
                throw new Exception(
                    "El ISBN solo debe contener números.");
            }

            if (libro.ISBN.Length != 10 &&
                libro.ISBN.Length != 13)
            {
                throw new Exception(
                    "El ISBN debe tener 10 o 13 dígitos.");
            }

            if (string.IsNullOrWhiteSpace(
                libro.Titulo))
            {
                throw new Exception(
                    "El título del libro es obligatorio.");
            }

            if (libro.IdAutor <= 0)
            {
                throw new Exception(
                    "Debe seleccionar un autor.");
            }

            if (libro.IdCategoria <= 0)
            {
                throw new Exception(
                    "Debe seleccionar una categoría.");
            }
        }

        private void ValidarCodigoUnico(
            string codigo,
            int idLibroActual)
        {
            List<Libro> libros =
                datos.Listar();

            bool existe =
                libros.Any(
                    l =>
                        l.Codigo.Equals(
                            codigo,
                            StringComparison.OrdinalIgnoreCase)
                        &&
                        l.IdLibro != idLibroActual);

            if (existe)
            {
                throw new Exception(
                    "Ya existe un libro registrado con ese código.");
            }
        }

        private void ValidarISBNUnico(
            string isbn,
            int idLibroActual)
        {
            List<Libro> libros =
                datos.Listar();

            bool existe =
                libros.Any(
                    l =>
                        l.ISBN.Equals(
                            isbn,
                            StringComparison.OrdinalIgnoreCase)
                        &&
                        l.IdLibro != idLibroActual);

            if (existe)
            {
                throw new Exception(
                    "Ya existe un libro registrado con ese ISBN.");
            }
        }
    }
}