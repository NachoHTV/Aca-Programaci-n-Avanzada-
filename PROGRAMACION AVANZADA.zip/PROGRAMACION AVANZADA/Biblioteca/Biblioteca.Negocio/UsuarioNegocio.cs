﻿using System;
using System.Linq;
using System.Text.RegularExpressions;
using Biblioteca.Datos;
using Biblioteca.Entidades;

namespace Biblioteca.Negocio
{
    public class UsuarioNegocio
    {
        private readonly UsuarioDatos datos =
            new UsuarioDatos();

        public List<Usuario> Listar()
        {
            return datos.Listar();
        }

        public void Registrar(Usuario usuario)
        {
            Validar(usuario);

            ValidarDocumentoUnico(
                usuario.Documento,
                0);

            datos.Insertar(usuario);
        }

        public void Actualizar(Usuario usuario)
        {
            if (usuario.IdUsuario <= 0)
                throw new Exception(
                    "El usuario seleccionado no es válido.");

            Validar(usuario);

            ValidarDocumentoUnico(
                usuario.Documento,
                usuario.IdUsuario);

            datos.Actualizar(usuario);
        }

        public void Eliminar(int idUsuario)
        {
            if (idUsuario <= 0)
                throw new Exception(
                    "Debe seleccionar un usuario válido.");

            datos.Eliminar(idUsuario);
        }

        private void Validar(Usuario usuario)
        {
            if (string.IsNullOrWhiteSpace(
                usuario.Documento))
            {
                throw new Exception(
                    "El documento es obligatorio.");
            }

            if (!usuario.Documento.All(char.IsDigit))
            {
                throw new Exception(
                    "El documento solo debe contener números.");
            }

            if (string.IsNullOrWhiteSpace(
                usuario.Nombre))
            {
                throw new Exception(
                    "El nombre es obligatorio.");
            }

            if (string.IsNullOrWhiteSpace(
                usuario.Apellidos))
            {
                throw new Exception(
                    "Los apellidos son obligatorios.");
            }

            if (string.IsNullOrWhiteSpace(
                usuario.Telefono))
            {
                throw new Exception(
                    "El teléfono es obligatorio.");
            }

            if (!usuario.Telefono.All(char.IsDigit))
            {
                throw new Exception(
                    "El teléfono solo debe contener números.");
            }

            if (usuario.Telefono.Length < 7 ||
                usuario.Telefono.Length > 15)
            {
                throw new Exception(
                    "El teléfono debe tener entre 7 y 15 dígitos.");
            }

            if (string.IsNullOrWhiteSpace(
                usuario.Correo))
            {
                throw new Exception(
                    "El correo es obligatorio.");
            }

            if (!Regex.IsMatch(
                usuario.Correo,
                @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
            {
                throw new Exception(
                    "El correo electrónico no tiene un formato válido.");
            }

            if (string.IsNullOrWhiteSpace(
                usuario.ProgramaAcademico))
            {
                throw new Exception(
                    "El programa académico es obligatorio.");
            }
        }

        private void ValidarDocumentoUnico(
            string documento,
            int idUsuarioActual)
        {
            List<Usuario> usuarios =
                datos.Listar();

            bool existe =
                usuarios.Any(
                    u =>
                        u.Documento.Equals(
                            documento,
                            StringComparison.OrdinalIgnoreCase)
                        &&
                        u.IdUsuario != idUsuarioActual);

            if (existe)
            {
                throw new Exception(
                    "Ya existe un usuario registrado con ese documento.");
            }
        }
    }
}