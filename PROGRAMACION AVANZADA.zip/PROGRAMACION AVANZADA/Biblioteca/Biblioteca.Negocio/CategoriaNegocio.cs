﻿using Biblioteca.Datos;
using Biblioteca.Entidades;

namespace Biblioteca.Negocio
{
    public class CategoriaNegocio
    {
        private readonly CategoriaDatos datos = new CategoriaDatos();

        public List<Categoria> Listar()
        {
            return datos.Listar();
        }

        public void Registrar(Categoria categoria)
        {
            Validar(categoria);
            datos.Insertar(categoria);
        }

        public void Actualizar(Categoria categoria)
        {
            if (categoria.IdCategoria <= 0)
                throw new Exception("La categoría seleccionada no es válida.");

            Validar(categoria);
            datos.Actualizar(categoria);
        }

        public void Eliminar(int idCategoria)
        {
            if (idCategoria <= 0)
                throw new Exception("Debe seleccionar una categoría válida.");

            datos.Eliminar(idCategoria);
        }

        private void Validar(Categoria categoria)
        {
            if (string.IsNullOrWhiteSpace(categoria.Nombre))
                throw new Exception("El nombre de la categoría es obligatorio.");
        }
    }
}