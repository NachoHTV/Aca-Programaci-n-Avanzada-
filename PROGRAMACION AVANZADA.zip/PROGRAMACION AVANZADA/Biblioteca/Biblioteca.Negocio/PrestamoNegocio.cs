﻿using Biblioteca.Datos;
using Biblioteca.Entidades;

namespace Biblioteca.Negocio
{
    public class PrestamoNegocio
    {
        private readonly PrestamoDatos prestamoDatos =
            new PrestamoDatos();

        private readonly DetallePrestamoDatos detalleDatos =
            new DetallePrestamoDatos();

        private readonly LibroDatos libroDatos =
            new LibroDatos();

        public List<Prestamo> Listar()
        {
            return prestamoDatos.Listar();
        }

        public int RegistrarPrestamo(
            int idUsuario,
            List<int> libros,
            DateTime fechaDevolucionEsperada)
        {
            if (idUsuario <= 0)
                throw new Exception(
                    "Debe seleccionar un usuario.");

            if (libros == null ||
                libros.Count == 0)
            {
                throw new Exception(
                    "Debe seleccionar al menos un libro.");
            }

            if (fechaDevolucionEsperada.Date <
                DateTime.Today)
            {
                throw new Exception(
                    "La fecha de devolución no puede ser anterior a la fecha actual.");
            }

            List<Libro> librosDisponibles =
                libroDatos.Listar();

            foreach (int idLibro in libros)
            {
                Libro? libro =
                    librosDisponibles.FirstOrDefault(
                        l => l.IdLibro == idLibro);

                if (libro == null)
                {
                    throw new Exception(
                        "Uno de los libros seleccionados no existe.");
                }

                if (libro.Disponible <= 0)
                {
                    throw new Exception(
                        $"El libro '{libro.Titulo}' no tiene ejemplares disponibles.");
                }
            }

            Prestamo prestamo =
                new Prestamo
                {
                    IdUsuario = idUsuario,
                    FechaPrestamo = DateTime.Now,
                    FechaDevolucionEsperada =
                        fechaDevolucionEsperada,
                    Estado = "Activo"
                };

            int idPrestamo =
                prestamoDatos.Insertar(prestamo);

            foreach (int idLibro in libros)
            {
                DetallePrestamo detalle =
                    new DetallePrestamo
                    {
                        IdPrestamo = idPrestamo,
                        IdLibro = idLibro,
                        FechaDevolucion = null
                    };

                detalleDatos.Insertar(detalle);

                libroDatos.CambiarDisponibilidad(
                    idLibro,
                    -1);
            }

            return idPrestamo;
        }

        public void RegistrarDevolucion(
            int idDetalle,
            int idLibro)
        {
            RegistrarDevolucion(
                idDetalle,
                idLibro,
                0);
        }

        public void RegistrarDevolucion(
            int idDetalle,
            int idLibro,
            int idPrestamo)
        {
            if (idDetalle <= 0)
                throw new Exception(
                    "El detalle del préstamo no es válido.");

            if (idLibro <= 0)
                throw new Exception(
                    "El libro no es válido.");

            detalleDatos.RegistrarDevolucion(
                idDetalle);

            libroDatos.CambiarDisponibilidad(
                idLibro,
                1);

            if (idPrestamo > 0)
            {
                List<DetallePrestamo> detalles =
                    detalleDatos.ListarPorPrestamo(
                        idPrestamo);

                bool todosDevueltos =
                    detalles.Count > 0 &&
                    detalles.All(
                        d => d.FechaDevolucion.HasValue);

                if (todosDevueltos)
                {
                    prestamoDatos.ActualizarEstado(
                        idPrestamo,
                        "Devuelto");
                }
            }
        }

        public List<DetallePrestamo> ListarDetalles(
            int idPrestamo)
        {
            if (idPrestamo <= 0)
            {
                throw new Exception(
                    "El préstamo seleccionado no es válido.");
            }

            return detalleDatos.ListarPorPrestamo(
                idPrestamo);
        }
    }
}