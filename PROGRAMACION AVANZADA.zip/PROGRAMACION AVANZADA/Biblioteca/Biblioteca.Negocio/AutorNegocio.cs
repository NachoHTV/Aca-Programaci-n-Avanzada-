﻿using Biblioteca.Datos;
using Biblioteca.Entidades;

namespace Biblioteca.Negocio
{
    public class AutorNegocio
    {
        private readonly AutorDatos datos = new AutorDatos();

        public List<Autor> Listar()
        {
            return datos.Listar();
        }

        public void Registrar(Autor autor)
        {
            Validar(autor);
            datos.Insertar(autor);
        }

        public void Actualizar(Autor autor)
        {
            if (autor.IdAutor <= 0)
                throw new Exception("El autor seleccionado no es válido.");

            Validar(autor);
            datos.Actualizar(autor);
        }

        public void Eliminar(int idAutor)
        {
            if (idAutor <= 0)
                throw new Exception("Debe seleccionar un autor válido.");

            datos.Eliminar(idAutor);
        }

        private void Validar(Autor autor)
        {
            if (string.IsNullOrWhiteSpace(autor.Codigo))
                throw new Exception("El código del autor es obligatorio.");

            if (string.IsNullOrWhiteSpace(autor.Nombre))
                throw new Exception("El nombre del autor es obligatorio.");

            if (string.IsNullOrWhiteSpace(autor.Apellidos))
                throw new Exception("Los apellidos del autor son obligatorios.");

            if (string.IsNullOrWhiteSpace(autor.Nacionalidad))
                throw new Exception("La nacionalidad es obligatoria.");
        }
    }
}