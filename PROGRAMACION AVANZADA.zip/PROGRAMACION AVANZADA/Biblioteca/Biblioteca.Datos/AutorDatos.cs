﻿using Biblioteca.Entidades;
using Microsoft.Data.SqlClient;

namespace Biblioteca.Datos
{
    public class AutorDatos
    {
        public List<Autor> Listar()
        {
            List<Autor> autores = new();

            using SqlConnection conexion = Conexion.ObtenerConexion();
            conexion.Open();

            string sql = @"
                SELECT IdAutor, Codigo, Nombre, Apellidos,
                       Nacionalidad, FechaNacimiento
                FROM Autores
                ORDER BY Apellidos, Nombre";

            using SqlCommand comando = new(sql, conexion);
            using SqlDataReader lector = comando.ExecuteReader();

            while (lector.Read())
            {
                autores.Add(new Autor
                {
                    IdAutor = Convert.ToInt32(lector["IdAutor"]),
                    Codigo = lector["Codigo"].ToString() ?? "",
                    Nombre = lector["Nombre"].ToString() ?? "",
                    Apellidos = lector["Apellidos"].ToString() ?? "",
                    Nacionalidad = lector["Nacionalidad"].ToString() ?? "",
                    FechaNacimiento = Convert.ToDateTime(lector["FechaNacimiento"])
                });
            }

            return autores;
        }

        public void Insertar(Autor autor)
        {
            using SqlConnection conexion = Conexion.ObtenerConexion();
            conexion.Open();

            string sql = @"
                INSERT INTO Autores
                (Codigo, Nombre, Apellidos, Nacionalidad, FechaNacimiento)
                VALUES
                (@Codigo, @Nombre, @Apellidos, @Nacionalidad, @FechaNacimiento)";

            using SqlCommand comando = new(sql, conexion);

            comando.Parameters.AddWithValue("@Codigo", autor.Codigo);
            comando.Parameters.AddWithValue("@Nombre", autor.Nombre);
            comando.Parameters.AddWithValue("@Apellidos", autor.Apellidos);
            comando.Parameters.AddWithValue("@Nacionalidad", autor.Nacionalidad);
            comando.Parameters.AddWithValue("@FechaNacimiento", autor.FechaNacimiento);

            comando.ExecuteNonQuery();
        }

        public void Actualizar(Autor autor)
        {
            using SqlConnection conexion = Conexion.ObtenerConexion();
            conexion.Open();

            string sql = @"
                UPDATE Autores
                SET Codigo = @Codigo,
                    Nombre = @Nombre,
                    Apellidos = @Apellidos,
                    Nacionalidad = @Nacionalidad,
                    FechaNacimiento = @FechaNacimiento
                WHERE IdAutor = @IdAutor";

            using SqlCommand comando = new(sql, conexion);

            comando.Parameters.AddWithValue("@IdAutor", autor.IdAutor);
            comando.Parameters.AddWithValue("@Codigo", autor.Codigo);
            comando.Parameters.AddWithValue("@Nombre", autor.Nombre);
            comando.Parameters.AddWithValue("@Apellidos", autor.Apellidos);
            comando.Parameters.AddWithValue("@Nacionalidad", autor.Nacionalidad);
            comando.Parameters.AddWithValue("@FechaNacimiento", autor.FechaNacimiento);

            comando.ExecuteNonQuery();
        }

        public void Eliminar(int idAutor)
        {
            using SqlConnection conexion = Conexion.ObtenerConexion();
            conexion.Open();

            string sql = "DELETE FROM Autores WHERE IdAutor = @IdAutor";

            using SqlCommand comando = new(sql, conexion);
            comando.Parameters.AddWithValue("@IdAutor", idAutor);

            comando.ExecuteNonQuery();
        }
    }
}