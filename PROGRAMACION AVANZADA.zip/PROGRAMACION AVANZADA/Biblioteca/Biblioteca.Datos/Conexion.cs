﻿using Microsoft.Data.SqlClient;

namespace Biblioteca.Datos
{
    public static class Conexion
    {
        private const string CadenaConexion =
            "Server=localhost\\SQLEXPRESS;Database=BibliotecaDB;Trusted_Connection=True;TrustServerCertificate=True;";

        public static SqlConnection ObtenerConexion()
        {
            return new SqlConnection(CadenaConexion);
        }
    }
}