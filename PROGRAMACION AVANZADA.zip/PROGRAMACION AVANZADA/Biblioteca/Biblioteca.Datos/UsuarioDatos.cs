﻿using Biblioteca.Entidades;
using Microsoft.Data.SqlClient;

namespace Biblioteca.Datos
{
    public class UsuarioDatos
    {
        public List<Usuario> Listar()
        {
            List<Usuario> usuarios = new();

            using SqlConnection conexion = Conexion.ObtenerConexion();
            conexion.Open();

            string sql = @"
                SELECT IdUsuario, Documento, Nombre, Apellidos,
                       Telefono, Correo, ProgramaAcademico
                FROM Usuarios
                ORDER BY Apellidos, Nombre";

            using SqlCommand comando = new(sql, conexion);
            using SqlDataReader lector = comando.ExecuteReader();

            while (lector.Read())
            {
                usuarios.Add(new Usuario
                {
                    IdUsuario = Convert.ToInt32(lector["IdUsuario"]),
                    Documento = lector["Documento"].ToString() ?? "",
                    Nombre = lector["Nombre"].ToString() ?? "",
                    Apellidos = lector["Apellidos"].ToString() ?? "",
                    Telefono = lector["Telefono"].ToString() ?? "",
                    Correo = lector["Correo"].ToString() ?? "",
                    ProgramaAcademico = lector["ProgramaAcademico"].ToString() ?? ""
                });
            }

            return usuarios;
        }

        public void Insertar(Usuario usuario)
        {
            using SqlConnection conexion = Conexion.ObtenerConexion();
            conexion.Open();

            string sql = @"
                INSERT INTO Usuarios
                (Documento, Nombre, Apellidos, Telefono, Correo, ProgramaAcademico)
                VALUES
                (@Documento, @Nombre, @Apellidos, @Telefono,
                 @Correo, @ProgramaAcademico)";

            using SqlCommand comando = new(sql, conexion);

            comando.Parameters.AddWithValue("@Documento", usuario.Documento);
            comando.Parameters.AddWithValue("@Nombre", usuario.Nombre);
            comando.Parameters.AddWithValue("@Apellidos", usuario.Apellidos);
            comando.Parameters.AddWithValue("@Telefono", usuario.Telefono);
            comando.Parameters.AddWithValue("@Correo", usuario.Correo);
            comando.Parameters.AddWithValue("@ProgramaAcademico", usuario.ProgramaAcademico);

            comando.ExecuteNonQuery();
        }

        public void Actualizar(Usuario usuario)
        {
            using SqlConnection conexion = Conexion.ObtenerConexion();
            conexion.Open();

            string sql = @"
                UPDATE Usuarios
                SET Documento = @Documento,
                    Nombre = @Nombre,
                    Apellidos = @Apellidos,
                    Telefono = @Telefono,
                    Correo = @Correo,
                    ProgramaAcademico = @ProgramaAcademico
                WHERE IdUsuario = @IdUsuario";

            using SqlCommand comando = new(sql, conexion);

            comando.Parameters.AddWithValue("@IdUsuario", usuario.IdUsuario);
            comando.Parameters.AddWithValue("@Documento", usuario.Documento);
            comando.Parameters.AddWithValue("@Nombre", usuario.Nombre);
            comando.Parameters.AddWithValue("@Apellidos", usuario.Apellidos);
            comando.Parameters.AddWithValue("@Telefono", usuario.Telefono);
            comando.Parameters.AddWithValue("@Correo", usuario.Correo);
            comando.Parameters.AddWithValue("@ProgramaAcademico", usuario.ProgramaAcademico);

            comando.ExecuteNonQuery();
        }

        public void Eliminar(int idUsuario)
        {
            using SqlConnection conexion = Conexion.ObtenerConexion();
            conexion.Open();

            string sql = @"
                DELETE FROM Usuarios
                WHERE IdUsuario = @IdUsuario";

            using SqlCommand comando = new(sql, conexion);
            comando.Parameters.AddWithValue("@IdUsuario", idUsuario);

            comando.ExecuteNonQuery();
        }
    }
}