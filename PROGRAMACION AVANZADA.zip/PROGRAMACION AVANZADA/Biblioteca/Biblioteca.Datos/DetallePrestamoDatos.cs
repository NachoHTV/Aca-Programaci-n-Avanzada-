﻿using Biblioteca.Entidades;
using Microsoft.Data.SqlClient;

namespace Biblioteca.Datos
{
    public class DetallePrestamoDatos
    {
        public List<DetallePrestamo> ListarPorPrestamo(int idPrestamo)
        {
            List<DetallePrestamo> detalles = new();

            using SqlConnection conexion = Conexion.ObtenerConexion();
            conexion.Open();

            string sql = @"
                SELECT IdDetalle, IdPrestamo, IdLibro, FechaDevolucion
                FROM DetallePrestamos
                WHERE IdPrestamo = @IdPrestamo";

            using SqlCommand comando = new(sql, conexion);
            comando.Parameters.AddWithValue("@IdPrestamo", idPrestamo);

            using SqlDataReader lector = comando.ExecuteReader();

            while (lector.Read())
            {
                detalles.Add(new DetallePrestamo
                {
                    IdDetalle = Convert.ToInt32(lector["IdDetalle"]),
                    IdPrestamo = Convert.ToInt32(lector["IdPrestamo"]),
                    IdLibro = Convert.ToInt32(lector["IdLibro"]),
                    FechaDevolucion = lector["FechaDevolucion"] == DBNull.Value
                        ? null
                        : Convert.ToDateTime(lector["FechaDevolucion"])
                });
            }

            return detalles;
        }

        public void Insertar(DetallePrestamo detalle)
        {
            using SqlConnection conexion = Conexion.ObtenerConexion();
            conexion.Open();

            string sql = @"
                INSERT INTO DetallePrestamos
                (IdPrestamo, IdLibro, FechaDevolucion)
                VALUES
                (@IdPrestamo, @IdLibro, @FechaDevolucion)";

            using SqlCommand comando = new(sql, conexion);

            comando.Parameters.AddWithValue("@IdPrestamo", detalle.IdPrestamo);
            comando.Parameters.AddWithValue("@IdLibro", detalle.IdLibro);

            comando.Parameters.AddWithValue(
                "@FechaDevolucion",
                detalle.FechaDevolucion.HasValue
                    ? detalle.FechaDevolucion.Value
                    : DBNull.Value);

            comando.ExecuteNonQuery();
        }

        public void RegistrarDevolucion(int idDetalle)
        {
            using SqlConnection conexion = Conexion.ObtenerConexion();
            conexion.Open();

            string sql = @"
                UPDATE DetallePrestamos
                SET FechaDevolucion = GETDATE()
                WHERE IdDetalle = @IdDetalle";

            using SqlCommand comando = new(sql, conexion);
            comando.Parameters.AddWithValue("@IdDetalle", idDetalle);

            comando.ExecuteNonQuery();
        }
    }
}