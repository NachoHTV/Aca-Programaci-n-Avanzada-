﻿using Biblioteca.Entidades;
using Microsoft.Data.SqlClient;

namespace Biblioteca.Datos
{
    public class PrestamoDatos
    {
        public List<Prestamo> Listar()
        {
            List<Prestamo> prestamos = new();

            using SqlConnection conexion = Conexion.ObtenerConexion();
            conexion.Open();

            string sql = @"
                SELECT IdPrestamo, IdUsuario, FechaPrestamo,
                       FechaDevolucionEsperada, Estado
                FROM Prestamos
                ORDER BY FechaPrestamo DESC";

            using SqlCommand comando = new(sql, conexion);
            using SqlDataReader lector = comando.ExecuteReader();

            while (lector.Read())
            {
                prestamos.Add(new Prestamo
                {
                    IdPrestamo = Convert.ToInt32(lector["IdPrestamo"]),
                    IdUsuario = Convert.ToInt32(lector["IdUsuario"]),
                    FechaPrestamo = Convert.ToDateTime(lector["FechaPrestamo"]),
                    FechaDevolucionEsperada =
                        Convert.ToDateTime(lector["FechaDevolucionEsperada"]),
                    Estado = lector["Estado"].ToString() ?? ""
                });
            }

            return prestamos;
        }

        public int Insertar(Prestamo prestamo)
        {
            using SqlConnection conexion = Conexion.ObtenerConexion();
            conexion.Open();

            string sql = @"
                INSERT INTO Prestamos
                (IdUsuario, FechaPrestamo, FechaDevolucionEsperada, Estado)
                OUTPUT INSERTED.IdPrestamo
                VALUES
                (@IdUsuario, @FechaPrestamo,
                 @FechaDevolucionEsperada, @Estado)";

            using SqlCommand comando = new(sql, conexion);

            comando.Parameters.AddWithValue("@IdUsuario", prestamo.IdUsuario);
            comando.Parameters.AddWithValue("@FechaPrestamo", prestamo.FechaPrestamo);
            comando.Parameters.AddWithValue(
                "@FechaDevolucionEsperada",
                prestamo.FechaDevolucionEsperada);
            comando.Parameters.AddWithValue("@Estado", prestamo.Estado);

            return Convert.ToInt32(comando.ExecuteScalar());
        }

        public void ActualizarEstado(int idPrestamo, string estado)
        {
            using SqlConnection conexion = Conexion.ObtenerConexion();
            conexion.Open();

            string sql = @"
                UPDATE Prestamos
                SET Estado = @Estado
                WHERE IdPrestamo = @IdPrestamo";

            using SqlCommand comando = new(sql, conexion);

            comando.Parameters.AddWithValue("@IdPrestamo", idPrestamo);
            comando.Parameters.AddWithValue("@Estado", estado);

            comando.ExecuteNonQuery();
        }
    }
}