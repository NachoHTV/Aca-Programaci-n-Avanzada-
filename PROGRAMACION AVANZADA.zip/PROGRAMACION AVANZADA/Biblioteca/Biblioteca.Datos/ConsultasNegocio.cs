﻿using System.Data;
using Biblioteca.Datos;

namespace Biblioteca.Negocio
{
    public class ConsultasNegocio
    {
        private readonly ConsultasDatos datos =
            new ConsultasDatos();

        public DataTable LibrosDisponibles()
        {
            return datos.LibrosDisponibles();
        }

        public DataTable LibrosPrestados()
        {
            return datos.LibrosPrestados();
        }

        public DataTable UsuariosConPrestamos()
        {
            return datos.UsuariosConPrestamos();
        }

        public DataTable HistorialPrestamos()
        {
            return datos.HistorialPrestamos();
        }

        public DataTable CantidadLibrosPorCategoria()
        {
            return datos.CantidadLibrosPorCategoria();
        }

        public DataTable CantidadLibrosPrestados()
        {
            return datos.CantidadLibrosPrestados();
        }
    }
}