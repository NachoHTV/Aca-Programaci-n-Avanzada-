﻿using System.Data;
using Microsoft.Data.SqlClient;

namespace Biblioteca.Datos
{
    public class ConsultasDatos
    {
        public DataTable LibrosDisponibles()
        {
            string sql = @"
                SELECT
                    l.Codigo,
                    l.ISBN,
                    l.Titulo,
                    a.Nombre + ' ' + a.Apellidos AS Autor,
                    c.Nombre AS Categoria,
                    l.Cantidad,
                    l.Disponible
                FROM Libros l
                INNER JOIN Autores a
                    ON l.IdAutor = a.IdAutor
                INNER JOIN Categorias c
                    ON l.IdCategoria = c.IdCategoria
                WHERE l.Disponible > 0
                ORDER BY l.Titulo";

            return EjecutarConsulta(sql);
        }

        public DataTable LibrosPrestados()
        {
            string sql = @"
                SELECT
                    l.Codigo,
                    l.Titulo,
                    a.Nombre + ' ' + a.Apellidos AS Autor,
                    u.Nombre + ' ' + u.Apellidos AS Usuario,
                    p.FechaPrestamo,
                    p.FechaDevolucionEsperada
                FROM DetallePrestamos d
                INNER JOIN Prestamos p
                    ON d.IdPrestamo = p.IdPrestamo
                INNER JOIN Libros l
                    ON d.IdLibro = l.IdLibro
                INNER JOIN Autores a
                    ON l.IdAutor = a.IdAutor
                INNER JOIN Usuarios u
                    ON p.IdUsuario = u.IdUsuario
                WHERE d.FechaDevolucion IS NULL
                ORDER BY p.FechaPrestamo DESC";

            return EjecutarConsulta(sql);
        }

        public DataTable UsuariosConPrestamos()
        {
            string sql = @"
                SELECT
                    u.Documento,
                    u.Nombre + ' ' + u.Apellidos AS Usuario,
                    u.ProgramaAcademico,
                    COUNT(DISTINCT p.IdPrestamo) AS CantidadPrestamos
                FROM Usuarios u
                INNER JOIN Prestamos p
                    ON u.IdUsuario = p.IdUsuario
                INNER JOIN DetallePrestamos d
                    ON p.IdPrestamo = d.IdPrestamo
                WHERE d.FechaDevolucion IS NULL
                GROUP BY
                    u.Documento,
                    u.Nombre,
                    u.Apellidos,
                    u.ProgramaAcademico
                ORDER BY Usuario";

            return EjecutarConsulta(sql);
        }

        public DataTable HistorialPrestamos()
        {
            string sql = @"
                SELECT
                    p.IdPrestamo,
                    u.Nombre + ' ' + u.Apellidos AS Usuario,
                    l.Titulo AS Libro,
                    p.FechaPrestamo,
                    p.FechaDevolucionEsperada,
                    d.FechaDevolucion,
                    CASE
                        WHEN d.FechaDevolucion IS NULL
                            THEN 'Pendiente'
                        ELSE 'Devuelto'
                    END AS Estado
                FROM Prestamos p
                INNER JOIN Usuarios u
                    ON p.IdUsuario = u.IdUsuario
                INNER JOIN DetallePrestamos d
                    ON p.IdPrestamo = d.IdPrestamo
                INNER JOIN Libros l
                    ON d.IdLibro = l.IdLibro
                ORDER BY p.FechaPrestamo DESC";

            return EjecutarConsulta(sql);
        }

        public DataTable CantidadLibrosPorCategoria()
        {
            string sql = @"
                SELECT
                    c.Nombre AS Categoria,
                    COUNT(l.IdLibro) AS CantidadLibros
                FROM Categorias c
                LEFT JOIN Libros l
                    ON c.IdCategoria = l.IdCategoria
                GROUP BY
                    c.IdCategoria,
                    c.Nombre
                ORDER BY c.Nombre";

            return EjecutarConsulta(sql);
        }

        public DataTable CantidadLibrosPrestados()
        {
            string sql = @"
                SELECT
                    COUNT(d.IdDetalle) AS LibrosPrestados
                FROM DetallePrestamos d
                WHERE d.FechaDevolucion IS NULL";

            return EjecutarConsulta(sql);
        }

        private DataTable EjecutarConsulta(string sql)
        {
            DataTable tabla = new DataTable();

            using SqlConnection conexion =
                Conexion.ObtenerConexion();

            conexion.Open();

            using SqlCommand comando =
                new SqlCommand(sql, conexion);

            using SqlDataAdapter adaptador =
                new SqlDataAdapter(comando);

            adaptador.Fill(tabla);

            return tabla;
        }
    }
}