﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Biblioteca.Negocio;
using static System.Net.Mime.MediaTypeNames;

namespace Biblioteca.Presentacion
{
    public class FrmConsultas : Form
    {
        private readonly ConsultasNegocio negocio;

        private ComboBox cboConsulta = null!;
        private Button btnConsultar = null!;
        private DataGridView dgvResultados = null!;
        private Label lblDescripcion = null!;

        public FrmConsultas()
        {
            negocio = new ConsultasNegocio();

            ConfigurarFormulario();
            CrearInterfaz();
        }

        private void ConfigurarFormulario()
        {
            Text = "Consultas";
            StartPosition = FormStartPosition.CenterScreen;
            Size = new Size(1100, 700);
            MinimumSize = new Size(950, 600);
            BackColor = Color.White;
        }

        private void CrearInterfaz()
        {
            Label titulo = new Label();

            titulo.Text = "CONSULTAS DE BIBLIOTECA";

            titulo.Font = new Font(
                "Segoe UI",
                24,
                FontStyle.Bold);

            titulo.ForeColor =
                Color.FromArgb(31, 78, 121);

            titulo.AutoSize = true;

            titulo.Location =
                new Point(330, 30);

            Controls.Add(titulo);

            Label etiqueta = new Label();

            etiqueta.Text =
                "Seleccione una consulta:";

            etiqueta.Font =
                new Font(
                    "Segoe UI",
                    10,
                    FontStyle.Bold);

            etiqueta.AutoSize = true;

            etiqueta.Location =
                new Point(70, 110);

            Controls.Add(etiqueta);

            cboConsulta = new ComboBox();

            cboConsulta.Location =
                new Point(250, 105);

            cboConsulta.Size =
                new Size(430, 30);

            cboConsulta.Font =
                new Font("Segoe UI", 10);

            cboConsulta.DropDownStyle =
                ComboBoxStyle.DropDownList;

            cboConsulta.Items.Add(
                "Libros disponibles");

            cboConsulta.Items.Add(
                "Libros prestados");

            cboConsulta.Items.Add(
                "Usuarios con préstamos");

            cboConsulta.Items.Add(
                "Historial de préstamos");

            cboConsulta.Items.Add(
                "Cantidad de libros por categoría");

            cboConsulta.Items.Add(
                "Cantidad de libros prestados");

            cboConsulta.SelectedIndex = 0;

            Controls.Add(cboConsulta);

            btnConsultar = CrearBoton(
                "Consultar",
                710,
                100,
                150,
                40,
                EjecutarConsulta);

            lblDescripcion = new Label();

            lblDescripcion.Text =
                "Seleccione una consulta y presione el botón.";

            lblDescripcion.Font =
                new Font(
                    "Segoe UI",
                    10,
                    FontStyle.Italic);

            lblDescripcion.ForeColor =
                Color.Gray;

            lblDescripcion.AutoSize = true;

            lblDescripcion.Location =
                new Point(70, 160);

            Controls.Add(lblDescripcion);

            dgvResultados = new DataGridView();

            dgvResultados.Location =
                new Point(70, 210);

            dgvResultados.Size =
                new Size(900, 350);

            dgvResultados.ReadOnly = true;

            dgvResultados.AllowUserToAddRows =
                false;

            dgvResultados.AllowUserToDeleteRows =
                false;

            dgvResultados.SelectionMode =
                DataGridViewSelectionMode.FullRowSelect;

            dgvResultados.MultiSelect = false;

            dgvResultados.AutoSizeColumnsMode =
                DataGridViewAutoSizeColumnsMode.Fill;

            dgvResultados.RowHeadersVisible =
                false;

            Controls.Add(dgvResultados);
        }

        private Button CrearBoton(
            string texto,
            int x,
            int y,
            int ancho,
            int alto,
            EventHandler evento)
        {
            Button boton = new Button();

            boton.Text = texto;

            boton.Font =
                new Font(
                    "Segoe UI",
                    10,
                    FontStyle.Bold);

            boton.Size =
                new Size(ancho, alto);

            boton.Location =
                new Point(x, y);

            boton.BackColor =
                Color.FromArgb(31, 78, 121);

            boton.ForeColor =
                Color.White;

            boton.FlatStyle =
                FlatStyle.Flat;

            boton.FlatAppearance.BorderSize = 0;

            boton.Cursor =
                Cursors.Hand;

            boton.Click += evento;

            Controls.Add(boton);

            return boton;
        }

        private void EjecutarConsulta(
            object? sender,
            EventArgs e)
        {
            try
            {
                if (cboConsulta.SelectedItem == null)
                    return;

                string consulta =
                    cboConsulta.SelectedItem.ToString()
                    ?? "";

                DataTable resultado;

                switch (consulta)
                {
                    case "Libros disponibles":

                        resultado =
                            negocio.LibrosDisponibles();

                        lblDescripcion.Text =
                            "Libros que actualmente tienen ejemplares disponibles.";

                        break;

                    case "Libros prestados":

                        resultado =
                            negocio.LibrosPrestados();

                        lblDescripcion.Text =
                            "Libros que actualmente se encuentran prestados.";

                        break;

                    case "Usuarios con préstamos":

                        resultado =
                            negocio.UsuariosConPrestamos();

                        lblDescripcion.Text =
                            "Usuarios que tienen préstamos pendientes.";

                        break;

                    case "Historial de préstamos":

                        resultado =
                            negocio.HistorialPrestamos();

                        lblDescripcion.Text =
                            "Historial completo de préstamos y devoluciones.";

                        break;

                    case "Cantidad de libros por categoría":

                        resultado =
                            negocio.CantidadLibrosPorCategoria();

                        lblDescripcion.Text =
                            "Cantidad de libros registrados en cada categoría.";

                        break;

                    case "Cantidad de libros prestados":

                        resultado =
                            negocio.CantidadLibrosPrestados();

                        lblDescripcion.Text =
                            "Cantidad total de libros actualmente prestados.";

                        break;

                    default:
                        return;
                }

                dgvResultados.DataSource = null;

                dgvResultados.DataSource =
                    resultado;

                ConfigurarEncabezados();

                if (resultado.Rows.Count == 0)
                {
                    MessageBox.Show(
                        "La consulta no encontró resultados.",
                        "Biblioteca",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "No se pudo ejecutar la consulta.\n\n"
                    + ex.Message,
                    "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void ConfigurarEncabezados()
        {
            foreach (DataGridViewColumn columna
                in dgvResultados.Columns)
            {
                columna.HeaderText =
                    columna.HeaderText
                        .Replace(
                            "IdPrestamo",
                            "ID préstamo")
                        .Replace(
                            "Codigo",
                            "Código")
                        .Replace(
                            "Titulo",
                            "Título")
                        .Replace(
                            "Categoria",
                            "Categoría")
                        .Replace(
                            "CantidadLibros",
                            "Cantidad de libros")
                        .Replace(
                            "LibrosPrestados",
                            "Libros prestados")
                        .Replace(
                            "FechaPrestamo",
                            "Fecha préstamo")
                        .Replace(
                            "FechaDevolucionEsperada",
                            "Devolución esperada")
                        .Replace(
                            "FechaDevolucion",
                            "Fecha devolución")
                        .Replace(
                            "ProgramaAcademico",
                            "Programa académico")
                        .Replace(
                            "CantidadPrestamos",
                            "Cantidad de préstamos");
            }
        }
    }
}