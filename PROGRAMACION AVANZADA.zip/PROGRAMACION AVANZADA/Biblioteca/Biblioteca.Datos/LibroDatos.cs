﻿using Biblioteca.Entidades;
using Microsoft.Data.SqlClient;

namespace Biblioteca.Datos
{
    public class LibroDatos
    {
        public List<Libro> Listar()
        {
            List<Libro> libros = new();

            using SqlConnection conexion = Conexion.ObtenerConexion();
            conexion.Open();

            string sql = @"
                SELECT IdLibro, Codigo, ISBN, Titulo,
                       IdAutor, IdCategoria, Cantidad, Disponible
                FROM Libros
                ORDER BY Titulo";

            using SqlCommand comando = new(sql, conexion);
            using SqlDataReader lector = comando.ExecuteReader();

            while (lector.Read())
            {
                libros.Add(new Libro
                {
                    IdLibro = Convert.ToInt32(lector["IdLibro"]),
                    Codigo = lector["Codigo"].ToString() ?? "",
                    ISBN = lector["ISBN"].ToString() ?? "",
                    Titulo = lector["Titulo"].ToString() ?? "",
                    IdAutor = Convert.ToInt32(lector["IdAutor"]),
                    IdCategoria = Convert.ToInt32(lector["IdCategoria"]),
                    Cantidad = Convert.ToInt32(lector["Cantidad"]),
                    Disponible = Convert.ToInt32(lector["Disponible"])
                });
            }

            return libros;
        }

        public void Insertar(Libro libro)
        {
            using SqlConnection conexion = Conexion.ObtenerConexion();
            conexion.Open();

            string sql = @"
                INSERT INTO Libros
                (Codigo, ISBN, Titulo, IdAutor, IdCategoria, Cantidad, Disponible)
                VALUES
                (@Codigo, @ISBN, @Titulo, @IdAutor, @IdCategoria,
                 @Cantidad, @Disponible)";

            using SqlCommand comando = new(sql, conexion);

            comando.Parameters.AddWithValue("@Codigo", libro.Codigo);
            comando.Parameters.AddWithValue("@ISBN", libro.ISBN);
            comando.Parameters.AddWithValue("@Titulo", libro.Titulo);
            comando.Parameters.AddWithValue("@IdAutor", libro.IdAutor);
            comando.Parameters.AddWithValue("@IdCategoria", libro.IdCategoria);
            comando.Parameters.AddWithValue("@Cantidad", libro.Cantidad);
            comando.Parameters.AddWithValue("@Disponible", libro.Disponible);

            comando.ExecuteNonQuery();
        }

        public void Actualizar(Libro libro)
        {
            using SqlConnection conexion = Conexion.ObtenerConexion();
            conexion.Open();

            string sql = @"
                UPDATE Libros
                SET Codigo = @Codigo,
                    ISBN = @ISBN,
                    Titulo = @Titulo,
                    IdAutor = @IdAutor,
                    IdCategoria = @IdCategoria,
                    Cantidad = @Cantidad,
                    Disponible = @Disponible
                WHERE IdLibro = @IdLibro";

            using SqlCommand comando = new(sql, conexion);

            comando.Parameters.AddWithValue("@IdLibro", libro.IdLibro);
            comando.Parameters.AddWithValue("@Codigo", libro.Codigo);
            comando.Parameters.AddWithValue("@ISBN", libro.ISBN);
            comando.Parameters.AddWithValue("@Titulo", libro.Titulo);
            comando.Parameters.AddWithValue("@IdAutor", libro.IdAutor);
            comando.Parameters.AddWithValue("@IdCategoria", libro.IdCategoria);
            comando.Parameters.AddWithValue("@Cantidad", libro.Cantidad);
            comando.Parameters.AddWithValue("@Disponible", libro.Disponible);

            comando.ExecuteNonQuery();
        }

        public void Eliminar(int idLibro)
        {
            using SqlConnection conexion = Conexion.ObtenerConexion();
            conexion.Open();

            string sql = @"
                DELETE FROM Libros
                WHERE IdLibro = @IdLibro";

            using SqlCommand comando = new(sql, conexion);
            comando.Parameters.AddWithValue("@IdLibro", idLibro);

            comando.ExecuteNonQuery();
        }

        public void CambiarDisponibilidad(int idLibro, int cantidad)
        {
            using SqlConnection conexion = Conexion.ObtenerConexion();
            conexion.Open();

            string sql = @"
                UPDATE Libros
                SET Disponible = Disponible + @Cantidad
                WHERE IdLibro = @IdLibro";

            using SqlCommand comando = new(sql, conexion);

            comando.Parameters.AddWithValue("@IdLibro", idLibro);
            comando.Parameters.AddWithValue("@Cantidad", cantidad);

            comando.ExecuteNonQuery();
        }
    }
}