﻿using Biblioteca.Entidades;
using Microsoft.Data.SqlClient;

namespace Biblioteca.Datos
{
    public class CategoriaDatos
    {
        public List<Categoria> Listar()
        {
            List<Categoria> categorias = new();

            using SqlConnection conexion = Conexion.ObtenerConexion();
            conexion.Open();

            string sql = @"
                SELECT IdCategoria, Nombre
                FROM Categorias
                ORDER BY Nombre";

            using SqlCommand comando = new(sql, conexion);
            using SqlDataReader lector = comando.ExecuteReader();

            while (lector.Read())
            {
                categorias.Add(new Categoria
                {
                    IdCategoria = Convert.ToInt32(lector["IdCategoria"]),
                    Nombre = lector["Nombre"].ToString() ?? ""
                });
            }

            return categorias;
        }

        public void Insertar(Categoria categoria)
        {
            using SqlConnection conexion = Conexion.ObtenerConexion();
            conexion.Open();

            string sql = @"
                INSERT INTO Categorias (Nombre)
                VALUES (@Nombre)";

            using SqlCommand comando = new(sql, conexion);
            comando.Parameters.AddWithValue("@Nombre", categoria.Nombre);

            comando.ExecuteNonQuery();
        }

        public void Actualizar(Categoria categoria)
        {
            using SqlConnection conexion = Conexion.ObtenerConexion();
            conexion.Open();

            string sql = @"
                UPDATE Categorias
                SET Nombre = @Nombre
                WHERE IdCategoria = @IdCategoria";

            using SqlCommand comando = new(sql, conexion);

            comando.Parameters.AddWithValue("@IdCategoria", categoria.IdCategoria);
            comando.Parameters.AddWithValue("@Nombre", categoria.Nombre);

            comando.ExecuteNonQuery();
        }

        public void Eliminar(int idCategoria)
        {
            using SqlConnection conexion = Conexion.ObtenerConexion();
            conexion.Open();

            string sql = @"
                DELETE FROM Categorias
                WHERE IdCategoria = @IdCategoria";

            using SqlCommand comando = new(sql, conexion);
            comando.Parameters.AddWithValue("@IdCategoria", idCategoria);

            comando.ExecuteNonQuery();
        }
    }
}